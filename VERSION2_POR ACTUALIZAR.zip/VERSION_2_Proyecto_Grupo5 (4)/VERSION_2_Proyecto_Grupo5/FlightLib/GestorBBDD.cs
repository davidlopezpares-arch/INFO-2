﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace Gestor
{
    public class GestorBBDD
    {
        SQLiteConnection cnx;

        public void Iniciar()
        {
            string dataSource = "Data Source=BaseDeDatos.db";
            cnx = new SQLiteConnection(dataSource);
            cnx.Open();
        }

        public void Cerrar()
        {
            cnx.Close();
        }

        public int RegistrarUsuario(string nombre, string contraseña)
        {
            DataTable dt = new DataTable();
            string sql = "SELECT * FROM usuarios WHERE nombre='" + nombre + "'";
            SQLiteDataAdapter adp = new SQLiteDataAdapter(sql, cnx);
            adp.Fill(dt);

            if (dt.Rows.Count > 0)
                return -1;

            sql = "INSERT INTO usuarios VALUES ('" + nombre + "', '" + contraseña + "')";
            SQLiteCommand command = new SQLiteCommand(sql, cnx);
            int filas = command.ExecuteNonQuery();

            if (filas == 1)
                return 0;
            else
                return -1;
        }

        public bool ValidarUsuario(string nombre, string contraseña)
        {
            DataTable dt = new DataTable();
            string sql = "SELECT * FROM usuarios WHERE nombre='" + nombre + "' AND contraseña='" + contraseña + "'";
            SQLiteDataAdapter adp = new SQLiteDataAdapter(sql, cnx);
            adp.Fill(dt);

            if (dt.Rows.Count == 1)
                return true;
            else
                return false;
        }
    }
}
   
