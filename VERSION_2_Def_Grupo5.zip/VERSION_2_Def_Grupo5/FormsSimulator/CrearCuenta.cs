﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Gestor;

namespace FormsSimulator
{
    public partial class CrearCuenta : Form
    {
        GestorBBDD mi_base = new GestorBBDD();
        public CrearCuenta()
        {
            InitializeComponent();
        }
        private void CrearCuenta_Load(object sender, EventArgs e)
        {
            mi_base.Iniciar();
        }
        public void SetUsuario(string usuario)
        {
            UsuarioNuevoTextBox.Text = usuario;
        }
        public void SetContraseña(string contraseña)
        {
            ContraseñaNuevaTextBox.Text = contraseña;
        }
        public string GetUsuario()
        {
            return UsuarioNuevoTextBox.Text;
        }
        public string GetContraseña()
        {
            return ContraseñaNuevaTextBox.Text;
        }
        // Acepta crear cuenta, comprueba que las contraseñas coinciden y que los campos no están vacíos, luego llama a la función RegistrarUsuario de GestorBBDD para crear la cuenta.
        private void AceptarButtonCrearCuenta_Click(object sender, EventArgs e)
        {
            if (ContraseñaNuevaTextBox.Text == RepiteContraseñaTextBox.Text)
            {
                if (UsuarioNuevoTextBox.Text != "" && ContraseñaNuevaTextBox.Text != "")
                {
                    string usuario = UsuarioNuevoTextBox.Text;
                    string contraseña = ContraseñaNuevaTextBox.Text;
                    int resultado = mi_base.RegistrarUsuario(usuario, contraseña);

                    if (resultado == 0)
                    {
                        MessageBox.Show("Cuenta creada correctamente. Ahora puede iniciar sesión con su nueva cuenta.");
                        mi_base.Cerrar(); 
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido crear la cuenta. El usuario puede que ya exista.");
                    }
                }
                else
                {
                    MessageBox.Show("Por favor, rellene todos los campos.");
                }
            }
            else
            {
                MessageBox.Show("Las contraseñas no coinciden. Por favor, inténtelo de nuevo.");
            }
        }

        private void VolverAtrasCrearCuenta_Click(object sender, EventArgs e)
        {
            mi_base.Cerrar();
            Close();
        }

    }
    }

