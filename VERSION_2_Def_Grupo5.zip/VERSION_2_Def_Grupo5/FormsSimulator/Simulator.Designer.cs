﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class Simulator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Simulator));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.opcionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cargarVuelosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distSeguridadYTCicloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoFormularioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.espacioAéreoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CerrarButton = new System.Windows.Forms.Button();
            this.SkipAutoCargasButton = new System.Windows.Forms.Button();
            this.LabelInformacionSimulador = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.opcionesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(780, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // opcionesToolStripMenuItem
            // 
            this.opcionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cargarVuelosToolStripMenuItem,
            this.distSeguridadYTCicloToolStripMenuItem,
            this.nuevoFormularioToolStripMenuItem,
            this.espacioAéreoToolStripMenuItem});
            this.opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            this.opcionesToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.opcionesToolStripMenuItem.Text = "Opciones";
            // 
            // cargarVuelosToolStripMenuItem
            // 
            this.cargarVuelosToolStripMenuItem.Name = "cargarVuelosToolStripMenuItem";
            this.cargarVuelosToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.cargarVuelosToolStripMenuItem.Text = "Cargar Vuelos";
            this.cargarVuelosToolStripMenuItem.Click += new System.EventHandler(this.cargarVuelosToolStripMenuItem_Click);
            // 
            // distSeguridadYTCicloToolStripMenuItem
            // 
            this.distSeguridadYTCicloToolStripMenuItem.Name = "distSeguridadYTCicloToolStripMenuItem";
            this.distSeguridadYTCicloToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.distSeguridadYTCicloToolStripMenuItem.Text = "Dist.Seguridad y T.Ciclo";
            this.distSeguridadYTCicloToolStripMenuItem.Click += new System.EventHandler(this.distSeguridadYTCicloToolStripMenuItem_Click);
            // 
            // nuevoFormularioToolStripMenuItem
            // 
            this.nuevoFormularioToolStripMenuItem.Name = "nuevoFormularioToolStripMenuItem";
            this.nuevoFormularioToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.nuevoFormularioToolStripMenuItem.Text = "Nuevo Formulario";
            this.nuevoFormularioToolStripMenuItem.Click += new System.EventHandler(this.nuevoFormularioToolStripMenuItem_Click);
            // 
            // espacioAéreoToolStripMenuItem
            // 
            this.espacioAéreoToolStripMenuItem.Name = "espacioAéreoToolStripMenuItem";
            this.espacioAéreoToolStripMenuItem.Size = new System.Drawing.Size(248, 26);
            this.espacioAéreoToolStripMenuItem.Text = "Espacio Aéreo";
            this.espacioAéreoToolStripMenuItem.Click += new System.EventHandler(this.espacioAéreoToolStripMenuItem_Click);
            // 
            // CerrarButton
            // 
            this.CerrarButton.Location = new System.Drawing.Point(309, 411);
            this.CerrarButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CerrarButton.Name = "CerrarButton";
            this.CerrarButton.Size = new System.Drawing.Size(195, 30);
            this.CerrarButton.TabIndex = 1;
            this.CerrarButton.Text = "Cerrar Simulador";
            this.CerrarButton.UseVisualStyleBackColor = true;
            this.CerrarButton.Click += new System.EventHandler(this.CerrarButton_Click);
            // 
            // SkipAutoCargasButton
            // 
            this.SkipAutoCargasButton.Location = new System.Drawing.Point(628, 50);
            this.SkipAutoCargasButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SkipAutoCargasButton.Name = "SkipAutoCargasButton";
            this.SkipAutoCargasButton.Size = new System.Drawing.Size(133, 50);
            this.SkipAutoCargasButton.TabIndex = 2;
            this.SkipAutoCargasButton.Text = "Skip a espacio aéreo";
            this.SkipAutoCargasButton.UseVisualStyleBackColor = true;
            this.SkipAutoCargasButton.Click += new System.EventHandler(this.SkipAutoCargasButton_Click);
            // 
            // LabelInformacionSimulador
            // 
            this.LabelInformacionSimulador.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelInformacionSimulador.Location = new System.Drawing.Point(254, 101);
            this.LabelInformacionSimulador.Name = "LabelInformacionSimulador";
            this.LabelInformacionSimulador.Size = new System.Drawing.Size(293, 240);
            this.LabelInformacionSimulador.TabIndex = 3;
            this.LabelInformacionSimulador.Text = resources.GetString("LabelInformacionSimulador.Text");
            this.LabelInformacionSimulador.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Simulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 475);
            this.Controls.Add(this.LabelInformacionSimulador);
            this.Controls.Add(this.SkipAutoCargasButton);
            this.Controls.Add(this.CerrarButton);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Simulator";
            this.Text = "Simulator";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem opcionesToolStripMenuItem;
        private ToolStripMenuItem nuevoFormularioToolStripMenuItem;
        private ToolStripMenuItem distSeguridadYTCicloToolStripMenuItem;
        private ToolStripMenuItem espacioAéreoToolStripMenuItem;
        private ToolStripMenuItem cargarVuelosToolStripMenuItem;
        private Button CerrarButton;
        private Button SkipAutoCargasButton;
        private Label LabelInformacionSimulador;
    }
}
