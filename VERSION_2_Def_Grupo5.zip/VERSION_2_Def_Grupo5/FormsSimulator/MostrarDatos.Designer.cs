﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class MostrarDatos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Matriz = new System.Windows.Forms.DataGridView();
            this.VolverAtrasBoton_MostrarDatos = new System.Windows.Forms.Button();
            this.InfoMostrarDatos = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Matriz)).BeginInit();
            this.SuspendLayout();
            // 
            // Matriz
            // 
            this.Matriz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Matriz.Location = new System.Drawing.Point(11, 10);
            this.Matriz.Margin = new System.Windows.Forms.Padding(2);
            this.Matriz.Name = "Matriz";
            this.Matriz.RowHeadersWidth = 62;
            this.Matriz.Size = new System.Drawing.Size(856, 439);
            this.Matriz.TabIndex = 0;
            this.Matriz.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Matriz_CellClick);
            // 
            // VolverAtrasBoton_MostrarDatos
            // 
            this.VolverAtrasBoton_MostrarDatos.Location = new System.Drawing.Point(384, 506);
            this.VolverAtrasBoton_MostrarDatos.Name = "VolverAtrasBoton_MostrarDatos";
            this.VolverAtrasBoton_MostrarDatos.Size = new System.Drawing.Size(137, 37);
            this.VolverAtrasBoton_MostrarDatos.TabIndex = 1;
            this.VolverAtrasBoton_MostrarDatos.Text = "Volver atrás";
            this.VolverAtrasBoton_MostrarDatos.UseVisualStyleBackColor = true;
            this.VolverAtrasBoton_MostrarDatos.Click += new System.EventHandler(this.VolverAtrasBoton_MostrarDatos_Click);
            // 
            // InfoMostrarDatos
            // 
            this.InfoMostrarDatos.AutoSize = true;
            this.InfoMostrarDatos.Font = new System.Drawing.Font("Calibri", 10F);
            this.InfoMostrarDatos.Location = new System.Drawing.Point(12, 460);
            this.InfoMostrarDatos.Name = "InfoMostrarDatos";
            this.InfoMostrarDatos.Size = new System.Drawing.Size(619, 24);
            this.InfoMostrarDatos.TabIndex = 2;
            this.InfoMostrarDatos.Text = "Haz clic en la columna de un avión para ver su distancia con otros vuelos";
            // 
            // MostrarDatos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.InfoMostrarDatos);
            this.Controls.Add(this.VolverAtrasBoton_MostrarDatos);
            this.Controls.Add(this.Matriz);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MostrarDatos";
            this.Text = "MostrarDatos";
            this.Load += new System.EventHandler(this.MostrarDatos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Matriz)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView Matriz;
        private Button VolverAtrasBoton_MostrarDatos;
        private Label InfoMostrarDatos;
    }
}