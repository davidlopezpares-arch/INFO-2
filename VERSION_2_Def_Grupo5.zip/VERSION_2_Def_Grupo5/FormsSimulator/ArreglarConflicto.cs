﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FormsSimulator
{
    public partial class ArreglarConflicto : Form
    {
        public ArreglarConflicto()
        {
            InitializeComponent();
        }
        FlightPlanList milista = new FlightPlanList();
        
        // Servirá para hacer las recomendaciones de las velocidades
        FlightPlanList nueva = new FlightPlanList();
        double distancia;
        int tiempo;
        
        // Servirá para guardar la velocidad original de todos los vuelos, en caso de querer volver a ponerlas o si no hay solucion
        double[] veloriginal;
        bool imposible = false;
        int intentos = 0;

        //Recibir y dar información
        public void SetFlightPlanList(FlightPlanList milista)
        {
            this.milista = milista;
            this.nueva = milista.Copia();
        }
        public void SetDistancia(double distancia)
        {
            this.distancia = distancia;
        }
        public void SetTiempo(int tiempo)
        {
            this.tiempo = tiempo;
        }
        public FlightPlanList GetLista()
        {
            return this.milista;
        }

        private void SiButton_Click(object sender, EventArgs e)
        {
            veloriginal = new double[milista.GetNumFlightPlans()];
            //Se guardan las velocidades originales de los vuelos
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                veloriginal[i] = milista.GetFlightPlan(i).GetVelocidad();
            }
            bool encontrado = false;

            //Mira si hay algun conflicto entre aviones
            while (ListaConflicto(milista) && !encontrado && intentos < 1000)
            {
                bool solucionado = false;
                while (!solucionado && !encontrado && intentos < 1000)
                {
                    //Modifica la velocidad de los dos aviones problematicos hasta que consigue solucionar el problema
                    double vel1 = milista.GetFlightPlan(v1).GetVelocidad();
                    double vel2 = milista.GetFlightPlan(v2).GetVelocidad();
                    if (vel1 > 1)
                    {
                        vel1 = vel1 - 1;
                    }
                    vel2 = vel2 + 1;
                    milista.GetFlightPlan(v1).SetVelocidad(vel1);
                    milista.GetFlightPlan(v2).SetVelocidad(vel2);
                    intentos = intentos + 1;
                    if (vel2 > 500)
                    {
                        encontrado = true;
                    }
                    else
                    {
                        if (!ListaConflicto(milista))
                        {
                            solucionado = true;
                        }
                    }
                }
            }
            //Si hace muchos intentos, se toma como solucion imposible
            if (intentos >= 1000)
            {
                encontrado = true;
            }
            if (encontrado)
            {
                //imposible de resolver, se vuelven a poner sus velocidades originales
                MessageBox.Show("No se ha podido solucionar el conflicto, cambia los datos de entrada");
                for (int i = 0; i < milista.GetNumFlightPlans(); i++)
                {
                    milista.GetFlightPlan(i).SetVelocidad(veloriginal[i]);
                }
                this.Close();
            }
            else
            {
                //Abre espacio aéreo
                MessageBox.Show("Se ha solucionado el conflicto");
                EspacioAéreo Form = new EspacioAéreo();
                Form.SetLista(milista);
                Form.SetDistancia(distancia);
                Form.SetTiempo(tiempo);
                Form.ShowDialog();
                this.Close();
            }
        }

        private void NoButton_Click(object sender, EventArgs e)
        {
            //Abre espacio aéreo
            EspacioAéreo Form = new EspacioAéreo();
            Form.SetLista(milista);
            Form.SetDistancia(distancia);
            Form.SetTiempo(tiempo);
            Form.ShowDialog();
            this.milista = Form.GetLista();
            this.Close();
        }
        int v1;
        int v2;

        //Comprueva si habrá conflicto en cualquier combinacion posible de aviones de la lista
        //Cambia el valor de los aviones problematicos v1 y v2
        public bool ListaConflicto(FlightPlanList lista)
        {
            bool conflicto = false;
            bool encontrado = false;
            int pasos = 0;

            for (int i = 0; i < lista.GetNumFlightPlans(); i++)
            {
                lista.GetFlightPlan(i).Restart();
            }
            while (!encontrado && !conflicto && pasos < 10000)
            {
                lista.Mover(tiempo);
                pasos = pasos + 1;
                v1 = 0;
                while (v1 < lista.GetNumFlightPlans() && !conflicto)
                {
                    v2 = v1 + 1;
                    while (v2 < lista.GetNumFlightPlans() && !conflicto)
                    {
                        if (lista.GetFlightPlan(v1).ConflictoActual(lista.GetFlightPlan(v2), 2 * distancia))
                        {
                            conflicto = true;
                        }
                        else
                        {
                            v2 = v2 + 1;
                        }
                    }
                    if (!conflicto)
                    {
                        v1 = v1 + 1;
                    }
                }
                encontrado = true;
                int k = 0;
                while (k < lista.GetNumFlightPlans())
                {
                    if (!lista.GetFlightPlan(k).EstaDestino())
                    {
                        encontrado = false;
                    }
                    k = k + 1;
                }
            }
            for (int i = 0; i < lista.GetNumFlightPlans(); i++)
            {
                lista.GetFlightPlan(i).Restart();
            }

            return conflicto;
        }

        private void ArreglarConflicto_Load(object sender, EventArgs e)
        {
            //Hace la misma reiteracion que el botón de si, pero para proponer las velocidades a las que se va a modificar

            veloriginal = new double[nueva.GetNumFlightPlans()];
            for (int i = 0; i < nueva.GetNumFlightPlans(); i++)
            {
                veloriginal[i] = nueva.GetFlightPlan(i).GetVelocidad();

            }

            while (ListaConflicto(nueva) && !imposible)
            {

                if (nueva.GetFlightPlan(v1).GetInitialPosition() == nueva.GetFlightPlan(v2).GetInitialPosition())
                {
                    imposible = true;
                }

                if (nueva.GetFlightPlan(v1).GetInitialPosition() == nueva.GetFlightPlan(v2).GetFinalPosition() && nueva.GetFlightPlan(v1).GetFinalPosition() == nueva.GetFlightPlan(v2).GetInitialPosition())
                {
                    imposible = true;
                }
                if (imposible)
                {
                    for (int i = 0; i < nueva.GetNumFlightPlans(); i++)
                    {
                        nueva.GetFlightPlan(i).SetVelocidad(veloriginal[i]);
                    }

                    RecomendacionVel.Text = "No se puede solucionar el conflicto.";
                }
                else
                {

                    bool solucionado = false;
                    while (!solucionado && !imposible && intentos < 1000)
                    {
                        double vel1 = nueva.GetFlightPlan(v1).GetVelocidad();
                        double vel2 = nueva.GetFlightPlan(v2).GetVelocidad();
                        if (vel1 > 1)
                        {
                            vel1 = vel1 - 1;
                        }
                        vel2 = vel2 + 1;
                        nueva.GetFlightPlan(v1).SetVelocidad(vel1);
                        nueva.GetFlightPlan(v2).SetVelocidad(vel2);
                        intentos = intentos + 1;
                        if (vel2 > 500)
                        {
                            imposible = true;
                        }
                        if (!ListaConflicto(nueva))
                        {
                            solucionado = true;
                        }
                    }
                    if (!solucionado)
                    {
                        imposible = true;
                    }
                }
                if (imposible || intentos >= 1000 || !ListaConflicto(nueva))
                {
                    string mensaje = "Velocidades recomendadas:\n";

                    for (int i = 0; i < nueva.GetNumFlightPlans(); i++)
                    {
                        mensaje = mensaje + "Velocidad del vuelo " + nueva.GetFlightPlan(i).GetId() + ": " + nueva.GetFlightPlan(i).GetVelocidad() + "\n";
                    }
                    RecomendacionVel.Text = mensaje;
                }
            }
        }
    }
}