﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class CargarArchivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.aceptarButton = new System.Windows.Forms.Button();
            this.vovleratrasButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.AutorellenarArchivo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(286, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Escribe el nombre del archivo:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.Location = new System.Drawing.Point(322, 124);
            this.nombreTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(125, 22);
            this.nombreTextBox.TabIndex = 1;
            // 
            // aceptarButton
            // 
            this.aceptarButton.Location = new System.Drawing.Point(313, 236);
            this.aceptarButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.aceptarButton.Name = "aceptarButton";
            this.aceptarButton.Size = new System.Drawing.Size(133, 40);
            this.aceptarButton.TabIndex = 2;
            this.aceptarButton.Text = "Aceptar y cargar";
            this.aceptarButton.UseVisualStyleBackColor = true;
            this.aceptarButton.Click += new System.EventHandler(this.aceptarButton_Click);
            // 
            // vovleratrasButton
            // 
            this.vovleratrasButton.Location = new System.Drawing.Point(614, 350);
            this.vovleratrasButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vovleratrasButton.Name = "vovleratrasButton";
            this.vovleratrasButton.Size = new System.Drawing.Size(133, 40);
            this.vovleratrasButton.TabIndex = 3;
            this.vovleratrasButton.Text = "Volver Atrás";
            this.vovleratrasButton.UseVisualStyleBackColor = true;
            this.vovleratrasButton.Click += new System.EventHandler(this.vovleratrasButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(297, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Prueba con FlightPlans.txt";
            // 
            // AutorellenarArchivo
            // 
            this.AutorellenarArchivo.Location = new System.Drawing.Point(313, 186);
            this.AutorellenarArchivo.Margin = new System.Windows.Forms.Padding(2);
            this.AutorellenarArchivo.Name = "AutorellenarArchivo";
            this.AutorellenarArchivo.Size = new System.Drawing.Size(133, 46);
            this.AutorellenarArchivo.TabIndex = 5;
            this.AutorellenarArchivo.Text = "Autorellenar archivo";
            this.AutorellenarArchivo.UseVisualStyleBackColor = true;
            this.AutorellenarArchivo.Click += new System.EventHandler(this.AutorellenarArchivo_Click);
            // 
            // CargarArchivo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 475);
            this.Controls.Add(this.AutorellenarArchivo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.vovleratrasButton);
            this.Controls.Add(this.aceptarButton);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CargarArchivo";
            this.Text = "CargarArchivo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox nombreTextBox;
        private Button aceptarButton;
        private Button vovleratrasButton;
        private Label label2;
        private Button AutorellenarArchivo;
    }
}