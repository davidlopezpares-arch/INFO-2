﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.IO;

namespace Gestor
{
    public class GestorBBDD
    {

        SQLiteConnection cnx;

        //Inicia la conexion con la base de datos
        public bool Iniciar()
        {
            if (!File.Exists("BaseDeDatos.db"))
            {
                return false;
            }
            try
            {
                string dataSource = "Data Source=BaseDeDatos.db";
                cnx = new SQLiteConnection(dataSource);
                cnx.Open();
                return true;
            }
            catch
            {
                return false;
            }
        }
       

        public void Cerrar()
        {
            cnx.Close();
        }
        //Registra los nuevos usuarios en la base de datos
        public int RegistrarUsuario(string nombre, string contraseña)
        {
            DataTable dt = new DataTable();
            string sql = "SELECT * FROM usuarios WHERE nombre='" + nombre + "'";
            SQLiteDataAdapter adp = new SQLiteDataAdapter(sql, cnx);
            adp.Fill(dt);

            if (dt.Rows.Count > 0)
                return -1;

            sql = "INSERT INTO usuarios VALUES ('" + nombre + "', '" + contraseña + "')";
            SQLiteCommand command = new SQLiteCommand(sql, cnx);
            int filas = command.ExecuteNonQuery();

            if (filas == 1)
                return 0;
            else
                return -1;
        }
        //Comprueva que el usuario y su contraseña existan en la base de datos
        public bool ValidarUsuario(string nombre, string contraseña)
        {
            DataTable dt = new DataTable();
            string sql = "SELECT * FROM usuarios WHERE nombre='" + nombre + "' AND contraseña='" + contraseña + "'";
            SQLiteDataAdapter adp = new SQLiteDataAdapter(sql, cnx);
            adp.Fill(dt);

            //Si lo encuentra , devuelve true, si no, devuelve false
            if (dt.Rows.Count == 1)
                return true;
            else
                return false;
        }
    }
}
   
