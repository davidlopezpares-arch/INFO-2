﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class FlightPlan
    {
        // Atributos

        string id; // identificador
        Position currentPosition; // posicion actual
        Position initialPosition; // posicion inicial
        Position finalPosition; // posicion final
        double velocidad;
        string compañia;

        // Constructures
        public FlightPlan(string id, string compañia, double cpx, double cpy, double fpx, double fpy, double velocidad)
        {
            this.id = id;
            this.compañia = compañia;
            this.currentPosition = new Position(cpx, cpy);
            this.initialPosition = new Position(cpx, cpy);
            this.finalPosition = new Position(fpx, fpy);
            this.velocidad = velocidad;
        }

        // Metodos
        public void SetVelocidad(double velocidad)
        // setter del atributo velocidad
        { this.velocidad = velocidad; }

        public void SetId(string id)
        // setter del atributo id
        { this.id = id; }

        public void SetCurrentPosition(Position position)
        // setter del atributo currentPosition
        { this.currentPosition = position; }

        public void SetFinalPosition(Position position)
        // setter del atributo finalPosition
        { this.finalPosition = position; }

        public double GetVelocidad()
        // getter del atributo velocidad
        { return this.velocidad; }

        public string GetId()
        // getter del atributo id
        { return this.id; }
        public string GetCompañia()
        {
            return this.compañia;
        }

        public void SetCompañia(string compañia)
        {
            this.compañia = compañia;
        }

        public Position GetCurrentPosition()
        // getter del atributo currentPosition
        { return this.currentPosition; }

        public Position GetFinalPosition()
        // getter del atributo finalPosition
        { return this.finalPosition; }

        public Position GetInitialPosition()
        // getter del atributo initialPosition
        { return this.initialPosition; }


        public void Mover(double tiempo)
        // Mueve el vuelo a la posición correspondiente a viajar durante el tiempo que se recibe como parámetro
        {
            //Calculamos la distancia recorrida en el tiempo dado
            double distancia = tiempo * this.velocidad/60;

            //Calculamos las razones trigonométricas
            double hipotenusa = Math.Sqrt((finalPosition.GetX() - currentPosition.GetX()) * (finalPosition.GetX() - currentPosition.GetX()) + (finalPosition.GetY() - currentPosition.GetY()) * (finalPosition.GetY() - currentPosition.GetY()));
            double coseno = (finalPosition.GetX() - currentPosition.GetX()) / hipotenusa;
            double seno = (finalPosition.GetY() - currentPosition.GetY()) / hipotenusa;

            //Caculamos la nueva posición del vuelo
            double x = currentPosition.GetX() + distancia * coseno;
            double y = currentPosition.GetY() + distancia * seno;

            Position nextPosition = new Position(x, y);

            // Modificar MoverVuelo para que no se pase del destino
            if (currentPosition.Distancia(nextPosition) < hipotenusa)
                currentPosition = nextPosition;
            else
                currentPosition = finalPosition;

        }

        // Hacer un metodo que diga si un vuelo ha llegado a su destino
        public bool EstaDestino()
        {
            bool resultado = false;
            if (currentPosition == finalPosition)
                resultado = true;

            return resultado;
        }

        // Función que mira si dos vuelos estan o van a estar en conflicto durante su trayecto
        public bool Conflicto(FlightPlan b, double distanciaSeguridad)
        {
            double X1 = this.currentPosition.GetX();
            double Y1 = this.currentPosition.GetY();
            double X2 = b.currentPosition.GetX();
            double Y2 = b.currentPosition.GetY();

            double dx = X2 - X1;
            double dy = Y2 - Y1;

            // Calculamos el ángulo de dirección de los dos aviones
            double alfa = Math.Atan2(this.finalPosition.GetY() - Y1,this.finalPosition.GetX() - X1);
            double vx1 = this.GetVelocidad() * Math.Cos(alfa);
            double vy1 = this.GetVelocidad() * Math.Sin(alfa);

            double beta = Math.Atan2(b.finalPosition.GetY() - Y2, b.finalPosition.GetX() - X2);
            double vx2 = b.GetVelocidad() * Math.Cos(beta);
            double vy2 = b.GetVelocidad() * Math.Sin(beta);

            double dvx = vx2-vx1;
            double dvy = vy2-vy1;

            // Comprovamos si hay movimiento relativo entre los dos vuelos
            if(dvx==0 && dvy == 0)
            {
                //La distancia entre los vuelos es siempre igual, solo hace falta mirar si estan en conflicto
                double Dist = Math.Sqrt(dx * dx + dy * dy);
                if (Dist < distanciaSeguridad)
                    return true;
                else
                {
                    return false;
                }
            }
            // Calculamos el instante en el que la distancia relativa entre los aviones es mínima
            double tmin = -(dx * dvx + dy * dvy) / (dvx * dvx + dvy * dvy);
            //Miramos que ese tiempo sea menor que el tiempo que tarda uno de los vuelos en llegar
            double t1final = this.GetCurrentPosition().Distancia(this.finalPosition) / this.GetVelocidad();
            double t2final = b.GetCurrentPosition().Distancia(b.finalPosition) / b.GetVelocidad();
            double tfinal = Math.Min(t1final, t2final);
            if (tmin < 0)
            {
                return false;
            }
            if (tmin > tfinal)
            {
                return false;
            }

            double xmin = dx + dvx * tmin;
            double ymin = dy + dvy * tmin;

            // Calculamos la distancia mínima entre los dos aviones
            double dmin = Math.Sqrt(xmin * xmin + ymin * ymin);

            if (dmin < distanciaSeguridad)
                return true;
            else
            {
                return false;
            }
        }
        //Comprueva si dos aviones estan en conflicto en el instante actual, sin tener en cuenta sus trayectorias futuras
        public bool ConflictoActual(FlightPlan b, double distanciaSeguridad)
        {
            double Dist = this.currentPosition.Distancia(b.currentPosition);
            if (Dist < distanciaSeguridad)
                return true;
            else
            {
                return false;
            }
        }

        public void EscribeConsola()
        // escribe en consola los datos del plan de vuelo
        {
            Console.WriteLine("******************************");
            Console.WriteLine("Datos del vuelo: ");
            Console.WriteLine("Identificador: {0}", id);
            Console.WriteLine("Velocidad: {0:F2}", velocidad);
            Console.WriteLine("Posición actual: ({0:F2}, {1:F2})", currentPosition.GetX(), currentPosition.GetY());
            if (this.EstaDestino())
                Console.WriteLine("Ha llegado al destino");
            Console.WriteLine("******************************");
        }

        public void Restart()
        // Devuelve la posición actual a la posición inicial proporcionada en el constructor
        {
            // Restauramos una copia de la posición inicial para evitar aliasing
            this.currentPosition = new Position(this.initialPosition.GetX(), this.initialPosition.GetY());
        }
        public double Distancia(FlightPlan f)
        // retorna la distancia entre los dos Postion
        {
            double resultado = Math.Sqrt(Math.Pow(this.currentPosition.GetX() - f.currentPosition.GetX(), 2) + Math.Pow(this.currentPosition.GetY() - f.currentPosition.GetY(), 2));
            return resultado;
        }

        public FlightPlan Copia()
        {
            FlightPlan copia = new FlightPlan( id, compañia, initialPosition.GetX(), initialPosition.GetY(), finalPosition.GetX(), finalPosition.GetY(),  velocidad);
            copia.SetCurrentPosition(new Position(currentPosition.GetX(), currentPosition.GetY()));
            return copia;
        }
    }
}