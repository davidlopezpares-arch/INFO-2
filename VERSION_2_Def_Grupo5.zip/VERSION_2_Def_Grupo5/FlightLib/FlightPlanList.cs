﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class FlightPlanList
    {
        //ATTRIBUTES
        List<FlightPlan> vector = new List<FlightPlan>();

        //METHODS
        //Añade un vuelo a la lista de vuelos
        public int AddFlightPlan(FlightPlan p)
        {
            vector.Add(p);
            return 0;
        }
        //Retorna el vuelo en una posicion i
        public FlightPlan GetFlightPlan(int i)
        {
            if (i < 0 || i >= vector.Count)
            {
                return null;
            }
            else
            {
                return vector[i]; 
            }
        }
        public int GetNumFlightPlans()
        {
            return vector.Count;
        }
        //Mueve toda la lista de vuelos un tiempo determinado, usando la funcion Mover de FlightPlan
        public void Mover(double tiempo)
        {
            int i = 0;
            while (i < vector.Count)
            {
                vector[i].Mover(tiempo);
                i++;
            }
        }
        //Escribe en consola la lista de vuelos (Actualmente no se usa ya)
        public void EscribeConsola()
        {
            int i = 0;
            while (i < vector.Count)
            {
                vector[i].EscribeConsola();
                i++;
            }
        }
        //Copia la lista de vuelos y devuelve la copia
        public FlightPlanList Copia()
        {
            FlightPlanList copia = new FlightPlanList();
            int i = 0;

            while (i < vector.Count)
            {
                copia.AddFlightPlan(vector[i].Copia());
                i++;
            }

            return copia;
        }
    }
}
