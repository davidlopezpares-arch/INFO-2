﻿namespace FormsSimulator
{
    partial class GuardarArchivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            aceptarButton = new Button();
            volveratrasButton = new Button();
            label1 = new Label();
            nombreTextBox = new TextBox();
            SuspendLayout();
            // 
            // aceptarButton
            // 
            aceptarButton.Location = new Point(280, 187);
            aceptarButton.Name = "aceptarButton";
            aceptarButton.Size = new Size(168, 29);
            aceptarButton.TabIndex = 0;
            aceptarButton.Text = "Aceptar y guardar";
            aceptarButton.UseVisualStyleBackColor = true;
            aceptarButton.Click += aceptarButton_Click;
            // 
            // volveratrasButton
            // 
            volveratrasButton.Location = new Point(652, 409);
            volveratrasButton.Name = "volveratrasButton";
            volveratrasButton.Size = new Size(127, 29);
            volveratrasButton.TabIndex = 1;
            volveratrasButton.Text = "Volver Atrás";
            volveratrasButton.UseVisualStyleBackColor = true;
            volveratrasButton.Click += volveratrasButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(248, 86);
            label1.Name = "label1";
            label1.Size = new Size(233, 20);
            label1.TabIndex = 2;
            label1.Text = "Escribe el nombre para el archivo:";
            // 
            // nombreTextBox
            // 
            nombreTextBox.Location = new Point(304, 134);
            nombreTextBox.Name = "nombreTextBox";
            nombreTextBox.Size = new Size(125, 27);
            nombreTextBox.TabIndex = 3;
            // 
            // GuardarArchivo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(nombreTextBox);
            Controls.Add(label1);
            Controls.Add(volveratrasButton);
            Controls.Add(aceptarButton);
            Name = "GuardarArchivo";
            Text = "GuardarArchivo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button aceptarButton;
        private Button volveratrasButton;
        private Label label1;
        private TextBox nombreTextBox;
    }
}