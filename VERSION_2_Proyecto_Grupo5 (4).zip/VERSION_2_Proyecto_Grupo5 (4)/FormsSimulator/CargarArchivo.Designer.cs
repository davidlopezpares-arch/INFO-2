﻿namespace FormsSimulator
{
    partial class CargarArchivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            nombreTextBox = new TextBox();
            aceptarButton = new Button();
            vovleratrasButton = new Button();
            label2 = new Label();
            AutorellenarArchivo = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(286, 115);
            label1.Name = "label1";
            label1.Size = new Size(208, 20);
            label1.TabIndex = 0;
            label1.Text = "Escribe el nombre del archivo:";
            label1.TextAlign = ContentAlignment.TopRight;
            // 
            // nombreTextBox
            // 
            nombreTextBox.Location = new Point(322, 155);
            nombreTextBox.Name = "nombreTextBox";
            nombreTextBox.Size = new Size(125, 27);
            nombreTextBox.TabIndex = 1;
            // 
            // aceptarButton
            // 
            aceptarButton.Location = new Point(313, 265);
            aceptarButton.Name = "aceptarButton";
            aceptarButton.Size = new Size(146, 29);
            aceptarButton.TabIndex = 2;
            aceptarButton.Text = "Aceptar y cargar";
            aceptarButton.UseVisualStyleBackColor = true;
            aceptarButton.Click += aceptarButton_Click;
            // 
            // vovleratrasButton
            // 
            vovleratrasButton.Location = new Point(655, 409);
            vovleratrasButton.Name = "vovleratrasButton";
            vovleratrasButton.Size = new Size(115, 29);
            vovleratrasButton.TabIndex = 3;
            vovleratrasButton.Text = "Volver Atrás";
            vovleratrasButton.UseVisualStyleBackColor = true;
            vovleratrasButton.Click += vovleratrasButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(297, 195);
            label2.Name = "label2";
            label2.Size = new Size(178, 20);
            label2.TabIndex = 4;
            label2.Text = "Prueba con FlightPlans.txt";
            // 
            // AutorellenarArchivo
            // 
            AutorellenarArchivo.Location = new Point(313, 233);
            AutorellenarArchivo.Margin = new Padding(2);
            AutorellenarArchivo.Name = "AutorellenarArchivo";
            AutorellenarArchivo.Size = new Size(146, 27);
            AutorellenarArchivo.TabIndex = 5;
            AutorellenarArchivo.Text = "Autorellenar archivo";
            AutorellenarArchivo.UseVisualStyleBackColor = true;
            AutorellenarArchivo.Click += AutorellenarArchivo_Click;
            // 
            // CargarArchivo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(AutorellenarArchivo);
            Controls.Add(label2);
            Controls.Add(vovleratrasButton);
            Controls.Add(aceptarButton);
            Controls.Add(nombreTextBox);
            Controls.Add(label1);
            Name = "CargarArchivo";
            Text = "CargarArchivo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox nombreTextBox;
        private Button aceptarButton;
        private Button vovleratrasButton;
        private Label label2;
        private Button AutorellenarArchivo;
    }
}