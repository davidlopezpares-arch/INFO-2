﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FormsSimulator
{
    public partial class ArreglarConflicto : Form
    {
        public ArreglarConflicto()
        {
            InitializeComponent();
        }
        FlightPlanList milista = new FlightPlanList();
        double distancia;
        int tiempo;
        double[] veloriginal;
        public void SetFlightPlanList(FlightPlanList milista)
        {
            this.milista = milista;
        }
        public void SetDistancia(double distancia)
        {
            this.distancia = distancia;
        }
        public void SetTiempo(int tiempo)
        {
            this.tiempo = tiempo;
        }
        public FlightPlanList GetLista()
        {
            return this.milista;
        }
        private void SiButton_Click(object sender, EventArgs e)
        {
            veloriginal = new double[milista.GetNumFlightPlans()];
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                veloriginal[i] = milista.GetFlightPlan(i).GetVelocidad();
            }
            bool encontrado = false;
            while (ListaConflicto() && !encontrado)
            {
                bool solucionado = false;
                while (!solucionado && !encontrado)
                {
                    double vel1 = milista.GetFlightPlan(v1).GetVelocidad();
                    double vel2 = milista.GetFlightPlan(v2).GetVelocidad();
                    if (vel1 > 1)
                    {
                        vel1 = vel1 - 1;
                    }
                    vel2 = vel2 + 1;
                    milista.GetFlightPlan(v1).SetVelocidad(vel1);
                    milista.GetFlightPlan(v2).SetVelocidad(vel2);
                    if (vel2 > 500)
                    {
                        encontrado = true;
                    }
                    else if (DistanciaMinima() >= 2 * distancia)
                    {
                        if (!ListaConflicto())
                        {
                            solucionado = true;
                        }
                    }
                }
            }
            if (encontrado)
            {
                MessageBox.Show("No se ha podido solucionar el conflicto, cambia los datos de entrada");
                for (int i = 0; i < milista.GetNumFlightPlans(); i++)
                {
                    milista.GetFlightPlan(i).SetVelocidad(veloriginal[i]);
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Se ha solucionado el conflicto");
                EspacioAéreo Form = new EspacioAéreo();
                Form.SetLista(milista);
                Form.SetDistancia(distancia);
                Form.SetTiempo(tiempo);
                Form.ShowDialog();
                this.Close();
            }
        }

        private void NoButton_Click(object sender, EventArgs e)
        {
            EspacioAéreo Form = new EspacioAéreo();
            Form.SetLista(milista);
            Form.SetDistancia(distancia);
            Form.SetTiempo(tiempo);
            Form.ShowDialog();
            this.milista = Form.GetLista();
            this.Close();
        }
        int v1;
        int v2;

        public bool ListaConflicto()
        {
            bool conflicto = false;
            bool encontrado = false;

            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                milista.GetFlightPlan(i).Restart();
            }
            while (!encontrado && !conflicto)
            {
                milista.Mover(tiempo);
                v1 = 0;
                while (v1 < milista.GetNumFlightPlans() && !conflicto)
                {
                    v2 = v1 + 1;
                    while (v2 < milista.GetNumFlightPlans() && !conflicto)
                    {
                        if (milista.GetFlightPlan(v1).ConflictoActual(
                            milista.GetFlightPlan(v2), 2 * distancia))
                        {
                            conflicto = true;
                        }
                        else
                        {
                            v2 = v2 + 1;
                        }
                    }
                    if (!conflicto)
                    {
                        v1 = v1 + 1;
                    }
                }
                encontrado = true;
                int k = 0;
                while (k < milista.GetNumFlightPlans())
                {
                    if (!milista.GetFlightPlan(k).EstaDestino())
                    {
                        encontrado = false;
                    }
                    k = k + 1;
                }
            }
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                milista.GetFlightPlan(i).Restart();
            }

            return conflicto;
        }

        public double DistanciaMinima()
        {
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                milista.GetFlightPlan(i).Restart();
            }
            double distanciaminima = milista.GetFlightPlan(v1).Distancia(milista.GetFlightPlan(v2));
            double tiempominimo = 1;
            while (!milista.GetFlightPlan(v1).EstaDestino() || !milista.GetFlightPlan(v2).EstaDestino())
            {
                milista.Mover(tiempominimo);
                if (milista.GetFlightPlan(v1).Distancia(milista.GetFlightPlan(v2)) < distanciaminima)
                {
                    distanciaminima = milista.GetFlightPlan(v1).Distancia(milista.GetFlightPlan(v2));
                }
            }
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                milista.GetFlightPlan(i).Restart();
            }
            return distanciaminima;
        }
    }
}
