﻿namespace FormsSimulator
{
    partial class CambiarVel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Vuelolbl = new Label();
            AceptarBtn = new Button();
            VelocidadBox = new TextBox();
            label2 = new Label();
            volveratrasButton = new Button();
            SuspendLayout();
            // 
            // Vuelolbl
            // 
            Vuelolbl.AutoSize = true;
            Vuelolbl.Location = new Point(72, 62);
            Vuelolbl.Margin = new Padding(2, 0, 2, 0);
            Vuelolbl.Name = "Vuelolbl";
            Vuelolbl.Size = new Size(50, 20);
            Vuelolbl.TabIndex = 0;
            Vuelolbl.Text = "label1";
            // 
            // AceptarBtn
            // 
            AceptarBtn.Location = new Point(482, 62);
            AceptarBtn.Margin = new Padding(2, 2, 2, 2);
            AceptarBtn.Name = "AceptarBtn";
            AceptarBtn.Size = new Size(90, 27);
            AceptarBtn.TabIndex = 1;
            AceptarBtn.Text = "Aceptar";
            AceptarBtn.UseVisualStyleBackColor = true;
            AceptarBtn.Click += AceptarBtn_Click;
            // 
            // VelocidadBox
            // 
            VelocidadBox.Location = new Point(248, 65);
            VelocidadBox.Margin = new Padding(2, 2, 2, 2);
            VelocidadBox.Name = "VelocidadBox";
            VelocidadBox.Size = new Size(121, 27);
            VelocidadBox.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(248, 30);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(121, 20);
            label2.TabIndex = 3;
            label2.Text = "Nueva Velocidad";
            // 
            // volveratrasButton
            // 
            volveratrasButton.Location = new Point(500, 319);
            volveratrasButton.Name = "volveratrasButton";
            volveratrasButton.Size = new Size(128, 29);
            volveratrasButton.TabIndex = 4;
            volveratrasButton.Text = "Volver Atrás";
            volveratrasButton.UseVisualStyleBackColor = true;
            volveratrasButton.Click += volveratrasButton_Click;
            // 
            // CambiarVel
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(volveratrasButton);
            Controls.Add(label2);
            Controls.Add(VelocidadBox);
            Controls.Add(AceptarBtn);
            Controls.Add(Vuelolbl);
            Margin = new Padding(2, 2, 2, 2);
            Name = "CambiarVel";
            Text = "CambiarVel";
            Load += CambiarVel_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Vuelolbl;
        private Button AceptarBtn;
        private TextBox VelocidadBox;
        private Label label2;
        private Button volveratrasButton;
    }
}