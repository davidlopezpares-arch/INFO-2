﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Numerics;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Windows.Forms;

namespace FormsSimulator
{
    public partial class EspacioAéreo : Form
    {
        FlightPlanList milista = new FlightPlanList();
        List<PictureBox> mispics = new List<PictureBox>();
        bool conflicto1 = false;
        double distanciaSeguridad;
        int tiempo;
        Stack<List<Position>> posiciones = new Stack<List<Position>>();
        public EspacioAéreo()
        {
            InitializeComponent();
        }
        public void SetLista(FlightPlanList milista)
        {
            this.milista = milista;
        }
        public FlightPlanList GetLista()
        {
            return this.milista;
        }
        public void SetDistancia(double distancia)
        {
            this.distanciaSeguridad = distancia;
        }
        public void SetTiempo(int tiempo)
        {
            this.tiempo = tiempo;
        }

        private void EspacioAéreo_Load(object sender, EventArgs e)
        {
            int i = 0;

            while (i < milista.GetNumFlightPlans())
            {
                FlightPlan A = milista.GetFlightPlan(i);

                int X1 = Convert.ToInt32(A.GetInitialPosition().GetX());
                int Y1 = Convert.ToInt32(A.GetInitialPosition().GetY());

                PictureBox pic1 = new PictureBox();
                pic1.Size = new Size(10, 10);
                pic1.BackColor = Color.Red;
                pic1.Location = new Point(X1 - 5, Y1 - 5);
                pic1.Click += pic_Click;

                AddPic(pic1);
                panel1.Controls.Add(pic1);

                i = i + 1;
            }
        }
        private bool HayConflicto()
        {
            int i = 0;

            while (i < milista.GetNumFlightPlans())
            {
                int j = i + 1;
                while (j < milista.GetNumFlightPlans())
                {
                    if (milista.GetFlightPlan(i).Conflicto(milista.GetFlightPlan(j), 2 * distanciaSeguridad))
                    {
                        return true;
                    }
                    j = j + 1;
                }
                i = i + 1;
            }
            return false;
        }
        private void Moverbutton_Click(object sender, EventArgs e)
        {

            List<Position> posicion = new List<Position>();
            for (int k = 0; k < milista.GetNumFlightPlans(); k++)
            {
                posicion.Add(milista.GetFlightPlan(k).GetCurrentPosition());
            }
            posiciones.Push(posicion);

            milista.Mover(tiempo);

            for (int i = 0; i < mispics.Count; i++)
            {
                FlightPlan plan = milista.GetFlightPlan(i);
                int X = Convert.ToInt32(plan.GetCurrentPosition().GetX());
                int Y = Convert.ToInt32(plan.GetCurrentPosition().GetY());
                mispics[i].Location = new Point(X - 5, Y - 5);
            }
            panel1.Invalidate();
            MostrarMensajeConflicto();

        }
        public void AddPic(PictureBox pic)
        {
            if (pic != null)
            {
                mispics.Add(pic);
            }
        }
        private void pic_Click(object sender, EventArgs e)
        {
            PictureBox pic = (PictureBox)sender;

            for (int i = 0; i < mispics.Count; i++)
            {
                if (mispics[i] == pic)
                {
                    InfoVuelo Form = new InfoVuelo();
                    Form.SetPlan(milista.GetFlightPlan(i));
                    Form.ShowDialog();
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < mispics.Count; i++)
            {
                FlightPlan aircraft = milista.GetFlightPlan(i);
                System.Drawing.Graphics graphics = e.Graphics;
                Pen myPen = new Pen(Color.Goldenrod);
                Point punto1 = new Point(Convert.ToInt32(aircraft.GetInitialPosition().GetX()), Convert.ToInt32(aircraft.GetInitialPosition().GetY()));
                Point punto2 = new Point(Convert.ToInt32(aircraft.GetFinalPosition().GetX()), Convert.ToInt32(aircraft.GetFinalPosition().GetY()));
                graphics.DrawLine(myPen, punto1, punto2);

                myPen = new Pen(Color.Blue);
                Point punto3 = new Point(Convert.ToInt32(aircraft.GetCurrentPosition().GetX() - distanciaSeguridad), Convert.ToInt32(aircraft.GetCurrentPosition().GetY() - distanciaSeguridad));
                int diametro = 2 * Convert.ToInt32(distanciaSeguridad);
                graphics.DrawEllipse(myPen, punto3.X, punto3.Y, diametro, diametro);
                int j = 0;
                while (j < milista.GetNumFlightPlans())
                {
                    if (i != j)
                    {
                        if (aircraft.ConflictoActual(milista.GetFlightPlan(j), 2 * distanciaSeguridad))
                        {
                            myPen = new Pen(Color.Red);
                            graphics.DrawEllipse(myPen, punto3.X, punto3.Y, diametro, diametro);
                        }
                    }

                    j = j + 1;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            List<Position> posicion = new List<Position>();
            for (int k = 0; k < milista.GetNumFlightPlans(); k++)
            {
                posicion.Add(milista.GetFlightPlan(k).GetCurrentPosition());
            }
            posiciones.Push(posicion);

            milista.Mover(tiempo);

            for (int i = 0; i < mispics.Count; i++)
            {
                FlightPlan plan = milista.GetFlightPlan(i);
                int X = Convert.ToInt32(plan.GetCurrentPosition().GetX());
                int Y = Convert.ToInt32(plan.GetCurrentPosition().GetY());
                mispics[i].Location = new Point(X - 5, Y - 5);
            }
            if (conflicto1)
            {
                timer1.Stop();
                Automáticobutton.Text = "Automático";
            }
            panel1.Invalidate();
            MostrarMensajeConflicto();
        }

        private void Automáticobutton_Click(object sender, EventArgs e)
        {
            if (Automáticobutton.Text == "Automático")
            {
                timer1.Interval = 500;
                timer1.Start();
                Automáticobutton.Text = "Parar";
            }
            else
            {
                timer1.Stop();
                Automáticobutton.Text = "Automático";
            }
        }

        private void MostarDatosButton_Click(object sender, EventArgs e)
        {
            MostrarDatos Form = new MostrarDatos();
            Form.SetLista(milista);
            Form.ShowDialog();
        }
        public void MostrarMensajeConflicto()
        {
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                FlightPlan aircraft = milista.GetFlightPlan(i);
                int j = 0;
                while (j < milista.GetNumFlightPlans())
                {
                    if (i != j)
                    {
                        if (aircraft.ConflictoActual(milista.GetFlightPlan(j), 2 * distanciaSeguridad) && !conflicto1)
                        {
                            conflicto1 = true;
                            MessageBox.Show("Traffic, Traffic, TCAS on");
                        }
                    }
                    j = j + 1;
                }
            }
        }
        private void Conflicto_Click(object sender, EventArgs e)
        {
            bool conflicto = HayConflicto();

            if (conflicto)
            {
                MessageBox.Show("Van a Chocar!!!!!!!!!!!");
            }
            else
            {
                MessageBox.Show("No habrá Conflicto");
            }
        }

        private void VolverAtrasBoton_EspacioAereo_Click(object sender, EventArgs e)
        {
            int i = 0;
            while (i < milista.GetNumFlightPlans())
            {
                milista.GetFlightPlan(i).Restart();
                i = i + 1;
            }
            Close();
        }
        private void CambiarVelocidad_Click(object sender, EventArgs e)
        {
            CambiarVel f = new CambiarVel();
            f.SetLista(milista);
            f.ShowDialog();
            this.milista = f.GetLista();
        }

        private void Restart_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                FlightPlan plan = milista.GetFlightPlan(i);
                plan.Restart();
                int X = Convert.ToInt32(plan.GetCurrentPosition().GetX());
                int Y = Convert.ToInt32(plan.GetCurrentPosition().GetY());
                mispics[i].Location = new Point(X - 5, Y - 5);
            }
            conflicto1 = false;
            panel1.Invalidate();
        }

        private void PuntoAnteriorButton_Click(object sender, EventArgs e)
        {
            if (posiciones.Count > 0)
            {
                List<Position> ultimaPosicion = posiciones.Pop();
                for (int i = 0; i < milista.GetNumFlightPlans(); i++)
                {
                    milista.GetFlightPlan(i).SetCurrentPosition(ultimaPosicion[i]);
                }
                for (int i = 0; i < milista.GetNumFlightPlans(); i++)
                {
                    FlightPlan plan = milista.GetFlightPlan(i);
                    int X = Convert.ToInt32(plan.GetCurrentPosition().GetX());
                    int Y = Convert.ToInt32(plan.GetCurrentPosition().GetY());
                    mispics[i].Location = new Point(X - 5, Y - 5);
                }
                panel1.Invalidate();
            }
            else
            {
                MessageBox.Show("No hay posiciones anteriores, Están en el inicio");
            }
        }
        private void guardarButton_Click(object sender, EventArgs e)
        {
            GuardarArchivo Form = new GuardarArchivo();
            Form.SetLista(milista);
            Form.ShowDialog();

        }
    }
}
