﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace FormsSimulator
{
    public partial class GuardarArchivo : Form
    {
        public GuardarArchivo()
        {
            InitializeComponent();
        }

        FlightPlanList milista = new FlightPlanList();
        public void SetLista(FlightPlanList lista)
        {
            this.milista = lista;
        }

        private void aceptarButton_Click(object sender, EventArgs e)
        {

            if (nombreTextBox == null || nombreTextBox.Text == "")
            {
                MessageBox.Show("Escribe un nombre para el archivo");
                return;
            }
            else
            {
                string nombre = nombreTextBox.Text;
                StreamWriter w = new StreamWriter(nombre);
                if(milista == null || milista.GetNumFlightPlans() == 0)
                {
                    MessageBox.Show("No hay planes de vuelo para guardar");
                    return;
                }
                else {
                    int i = 0;
                    while (i < milista.GetNumFlightPlans())
                    {
                        FlightPlan p = milista.GetFlightPlan(i);
                        w.WriteLine(p.GetId() + " " + p.GetCurrentPosition().GetX() + " " + p.GetCurrentPosition().GetY() + " " + p.GetFinalPosition().GetX() + " " + p.GetFinalPosition().GetY() + " " + p.GetVelocidad());
                        i = i + 1;
                    }
                    w.Close();
                    MessageBox.Show("Se ha guardado la simulación correctamente en el archivo " + nombre);
                    this.Close();
                
                }
            }
        }

        private void volveratrasButton_Click(object sender, EventArgs e)
        {
            this.Close();  
        }
    }
}

