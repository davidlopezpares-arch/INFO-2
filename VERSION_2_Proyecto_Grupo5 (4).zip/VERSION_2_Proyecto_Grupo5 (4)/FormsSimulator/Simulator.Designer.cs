﻿namespace FormsSimulator
{
    partial class Simulator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            opcionesToolStripMenuItem = new ToolStripMenuItem();
            nuevoFormularioToolStripMenuItem = new ToolStripMenuItem();
            distSeguridadYTCicloToolStripMenuItem = new ToolStripMenuItem();
            espacioAéreoToolStripMenuItem = new ToolStripMenuItem();
            cargarVuelosToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { opcionesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(640, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // opcionesToolStripMenuItem
            // 
            opcionesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cargarVuelosToolStripMenuItem, distSeguridadYTCicloToolStripMenuItem, nuevoFormularioToolStripMenuItem, espacioAéreoToolStripMenuItem });
            opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            opcionesToolStripMenuItem.Size = new Size(85, 24);
            opcionesToolStripMenuItem.Text = "Opciones";
            // 
            // nuevoFormularioToolStripMenuItem
            // 
            nuevoFormularioToolStripMenuItem.Name = "nuevoFormularioToolStripMenuItem";
            nuevoFormularioToolStripMenuItem.Size = new Size(248, 26);
            nuevoFormularioToolStripMenuItem.Text = "Nuevo Formulario";
            nuevoFormularioToolStripMenuItem.Click += nuevoFormularioToolStripMenuItem_Click;
            // 
            // distSeguridadYTCicloToolStripMenuItem
            // 
            distSeguridadYTCicloToolStripMenuItem.Name = "distSeguridadYTCicloToolStripMenuItem";
            distSeguridadYTCicloToolStripMenuItem.Size = new Size(248, 26);
            distSeguridadYTCicloToolStripMenuItem.Text = "Dist.Seguridad y T.Ciclo";
            distSeguridadYTCicloToolStripMenuItem.Click += distSeguridadYTCicloToolStripMenuItem_Click;
            // 
            // espacioAéreoToolStripMenuItem
            // 
            espacioAéreoToolStripMenuItem.Name = "espacioAéreoToolStripMenuItem";
            espacioAéreoToolStripMenuItem.Size = new Size(248, 26);
            espacioAéreoToolStripMenuItem.Text = "Espacio Aéreo";
            espacioAéreoToolStripMenuItem.Click += espacioAéreoToolStripMenuItem_Click;
            // 
            // cargarVuelosToolStripMenuItem
            // 
            cargarVuelosToolStripMenuItem.Name = "cargarVuelosToolStripMenuItem";
            cargarVuelosToolStripMenuItem.Size = new Size(248, 26);
            cargarVuelosToolStripMenuItem.Text = "Cargar Vuelos";
            cargarVuelosToolStripMenuItem.Click += cargarVuelosToolStripMenuItem_Click;
            // 
            // Simulator
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2);
            Name = "Simulator";
            Text = "Simulator";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem opcionesToolStripMenuItem;
        private ToolStripMenuItem nuevoFormularioToolStripMenuItem;
        private ToolStripMenuItem distSeguridadYTCicloToolStripMenuItem;
        private ToolStripMenuItem espacioAéreoToolStripMenuItem;
        private ToolStripMenuItem cargarVuelosToolStripMenuItem;
    }
}
