﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlightLib;

namespace SimulatorConsole
{
    public class Program
    {
        static void Main(string[] args)
        {
            FlightPlanList lista = new FlightPlanList();
            try
            {
                Console.WriteLine("Escribe el identificador");
                //   string nombre = Console.ReadLine();
                string identificador = Console.ReadLine(); ;

                Console.WriteLine("Escribe la velocidad");
                double velocidad = Convert.ToDouble(Console.ReadLine());


                Console.WriteLine("Escribe las coordenadas de la posición inicial, separadas por un blanco");
                string linea = Console.ReadLine();
                string[] trozos = linea.Split(' ');
                double ix = Convert.ToDouble(trozos[0]);
                double iy = Convert.ToDouble(trozos[1]);
              
                Console.WriteLine("Escribe las coordenadas de la posición final, separadas por un blanco");
                linea = Console.ReadLine();
                trozos = linea.Split(' ');
                double fx = Convert.ToDouble(trozos[0]);
                double fy = Convert.ToDouble(trozos[1]);

                FlightPlan plan_a = new FlightPlan(identificador, ix, iy, fx, fy, velocidad);

                Console.WriteLine("Escribe el identificador");
                //   string nombre = Console.ReadLine();
                 identificador = Console.ReadLine(); ;

                Console.WriteLine("Escribe la velocidad");
                 velocidad = Convert.ToDouble(Console.ReadLine());


                Console.WriteLine("Escribe las coordenadas de la posición inicial, separadas por un blanco");
                 linea = Console.ReadLine();
                trozos = linea.Split(' ');
                 ix = Convert.ToDouble(trozos[0]);
                 iy = Convert.ToDouble(trozos[1]);

                Console.WriteLine("Escribe las coordenadas de la posición final, separadas por un blanco");
                linea = Console.ReadLine();
                trozos = linea.Split(' ');
                 fx = Convert.ToDouble(trozos[0]);
                 fy = Convert.ToDouble(trozos[1]);
                
                FlightPlan plan_b = new FlightPlan(identificador, ix, iy, fx, fy, velocidad);
                lista.AddFlightPlan(plan_a);
                lista.AddFlightPlan(plan_b);

                Console.WriteLine("Cuantos ciclos de 10 segundos quieres simular?");
                linea = Console.ReadLine();
                int ciclos = Convert.ToInt32(linea);
                int i = 0;
                double distanciaSeguridad = 10;
                while (i < ciclos)
                {
                    lista.Mover(10);
                    lista.EscribeConsola();
                    if (lista.GetFlightPlan(0).ConflictoActual(lista.GetFlightPlan(1), distanciaSeguridad))
                    {
                        Console.WriteLine("Conflicto detectado");
                    }
                    i++;
                }
                Console.ReadLine();

            }
            catch (FormatException)
            {
                Console.WriteLine("Error en el formato de los datos de entrada");
            }
        }
    }
}
