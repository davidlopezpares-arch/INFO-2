﻿namespace FormsSimulator
{
    partial class NuevoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Id1 = new TextBox();
            PosicionInicial1 = new TextBox();
            PosicionFinal1 = new TextBox();
            Velocidad1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            Velocidad2 = new TextBox();
            PosicionFinal2 = new TextBox();
            PosicionInicial2 = new TextBox();
            Id2 = new TextBox();
            Aceptarbutton = new Button();
            AutorellenarBoton = new Button();
            VolverAtrasNuevoForm = new Button();
            CompaniaLabel1 = new Label();
            Compania1 = new TextBox();
            CompaniaLabel2 = new Label();
            Compania2 = new TextBox();
            SuspendLayout();
            // 
            // Id1
            // 
            Id1.Location = new Point(151, 50);
            Id1.Margin = new Padding(2);
            Id1.Name = "Id1";
            Id1.Size = new Size(121, 27);
            Id1.TabIndex = 0;
            // 
            // PosicionInicial1
            // 
            PosicionInicial1.Location = new Point(151, 110);
            PosicionInicial1.Margin = new Padding(2);
            PosicionInicial1.Name = "PosicionInicial1";
            PosicionInicial1.Size = new Size(121, 27);
            PosicionInicial1.TabIndex = 1;
            // 
            // PosicionFinal1
            // 
            PosicionFinal1.Location = new Point(151, 173);
            PosicionFinal1.Margin = new Padding(2);
            PosicionFinal1.Name = "PosicionFinal1";
            PosicionFinal1.Size = new Size(121, 27);
            PosicionFinal1.TabIndex = 2;
            // 
            // Velocidad1
            // 
            Velocidad1.Location = new Point(151, 228);
            Velocidad1.Margin = new Padding(2);
            Velocidad1.Name = "Velocidad1";
            Velocidad1.Size = new Size(121, 27);
            Velocidad1.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(151, 23);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 4;
            label1.Text = "Vuelo 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(57, 53);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(94, 20);
            label2.TabIndex = 5;
            label2.Text = "Identificador";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 113);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(137, 20);
            label3.TabIndex = 6;
            label3.Text = "Posición Inicial (x,y)";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 175);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(129, 20);
            label4.TabIndex = 7;
            label4.Text = "Posición Final (x,y)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(75, 231);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(75, 20);
            label5.TabIndex = 8;
            label5.Text = "Velocidad";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(350, 228);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(75, 20);
            label6.TabIndex = 17;
            label6.Text = "Velocidad";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(299, 172);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(129, 20);
            label7.TabIndex = 16;
            label7.Text = "Posición Final (x,y)";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(293, 113);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(137, 20);
            label8.TabIndex = 15;
            label8.Text = "Posición Inicial (x,y)";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(332, 50);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(94, 20);
            label9.TabIndex = 14;
            label9.Text = "Identificador";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(426, 21);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(59, 20);
            label10.TabIndex = 13;
            label10.Text = "Vuelo 2";
            // 
            // Velocidad2
            // 
            Velocidad2.Location = new Point(426, 226);
            Velocidad2.Margin = new Padding(2);
            Velocidad2.Name = "Velocidad2";
            Velocidad2.Size = new Size(121, 27);
            Velocidad2.TabIndex = 12;
            // 
            // PosicionFinal2
            // 
            PosicionFinal2.Location = new Point(426, 170);
            PosicionFinal2.Margin = new Padding(2);
            PosicionFinal2.Name = "PosicionFinal2";
            PosicionFinal2.Size = new Size(121, 27);
            PosicionFinal2.TabIndex = 11;
            // 
            // PosicionInicial2
            // 
            PosicionInicial2.Location = new Point(426, 107);
            PosicionInicial2.Margin = new Padding(2);
            PosicionInicial2.Name = "PosicionInicial2";
            PosicionInicial2.Size = new Size(121, 27);
            PosicionInicial2.TabIndex = 10;
            // 
            // Id2
            // 
            Id2.Location = new Point(426, 48);
            Id2.Margin = new Padding(2);
            Id2.Name = "Id2";
            Id2.Size = new Size(121, 27);
            Id2.TabIndex = 9;
            // 
            // Aceptarbutton
            // 
            Aceptarbutton.Location = new Point(242, 313);
            Aceptarbutton.Margin = new Padding(2);
            Aceptarbutton.Name = "Aceptarbutton";
            Aceptarbutton.Size = new Size(147, 27);
            Aceptarbutton.TabIndex = 18;
            Aceptarbutton.Text = "Aceptar y guardar";
            Aceptarbutton.UseVisualStyleBackColor = true;
            Aceptarbutton.Click += Aceptarbutton_Click;
            // 
            // AutorellenarBoton
            // 
            AutorellenarBoton.Location = new Point(94, 311);
            AutorellenarBoton.Name = "AutorellenarBoton";
            AutorellenarBoton.Size = new Size(144, 29);
            AutorellenarBoton.TabIndex = 19;
            AutorellenarBoton.Text = "Autorellenar Datos";
            AutorellenarBoton.UseVisualStyleBackColor = true;
            AutorellenarBoton.Click += AutorellenarBoton_Click;
            // 
            // VolverAtrasNuevoForm
            // 
            VolverAtrasNuevoForm.Location = new Point(394, 313);
            VolverAtrasNuevoForm.Margin = new Padding(2);
            VolverAtrasNuevoForm.Name = "VolverAtrasNuevoForm";
            VolverAtrasNuevoForm.Size = new Size(99, 27);
            VolverAtrasNuevoForm.TabIndex = 20;
            VolverAtrasNuevoForm.Text = "Volver atrás";
            VolverAtrasNuevoForm.UseVisualStyleBackColor = true;
            VolverAtrasNuevoForm.Click += VolverAtrasNuevoForm_Click;
            // 
            // CompaniaLabel1
            // 
            CompaniaLabel1.AutoSize = true;
            CompaniaLabel1.Location = new Point(60, 278);
            CompaniaLabel1.Name = "CompaniaLabel1";
            CompaniaLabel1.Size = new Size(85, 20);
            CompaniaLabel1.TabIndex = 21;
            CompaniaLabel1.Text = "Compañia1";
            // 
            // Compania1
            // 
            Compania1.Location = new Point(151, 275);
            Compania1.Name = "Compania1";
            Compania1.Size = new Size(125, 27);
            Compania1.TabIndex = 22;
            // 
            // CompaniaLabel2
            // 
            CompaniaLabel2.AutoSize = true;
            CompaniaLabel2.Location = new Point(335, 282);
            CompaniaLabel2.Name = "CompaniaLabel2";
            CompaniaLabel2.Size = new Size(85, 20);
            CompaniaLabel2.TabIndex = 23;
            CompaniaLabel2.Text = "Compañia2";
            // 
            // Compania2
            // 
            Compania2.Location = new Point(426, 275);
            Compania2.Name = "Compania2";
            Compania2.Size = new Size(125, 27);
            Compania2.TabIndex = 24;
            // 
            // NuevoForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(Compania2);
            Controls.Add(CompaniaLabel2);
            Controls.Add(Compania1);
            Controls.Add(CompaniaLabel1);
            Controls.Add(VolverAtrasNuevoForm);
            Controls.Add(AutorellenarBoton);
            Controls.Add(Aceptarbutton);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(Velocidad2);
            Controls.Add(PosicionFinal2);
            Controls.Add(PosicionInicial2);
            Controls.Add(Id2);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Velocidad1);
            Controls.Add(PosicionFinal1);
            Controls.Add(PosicionInicial1);
            Controls.Add(Id1);
            Margin = new Padding(2);
            Name = "NuevoForm";
            Text = "NuevoForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Id1;
        private TextBox PosicionInicial1;
        private TextBox PosicionFinal1;
        private TextBox Velocidad1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private TextBox Velocidad2;
        private TextBox PosicionFinal2;
        private TextBox PosicionInicial2;
        private TextBox Id2;
        private Button Aceptarbutton;
        private Button AutorellenarBoton;
        private Button VolverAtrasNuevoForm;
        private Label CompaniaLabel1;
        private TextBox Compania1;
        private Label CompaniaLabel2;
        private TextBox Compania2;
    }
}