﻿namespace FormsSimulator
{
    partial class InicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TituloInicioSesion = new Label();
            UsuarioTextBox = new TextBox();
            ContraseñaTextBox = new TextBox();
            UsuarioLabel = new Label();
            ContraseñaLabel = new Label();
            AceptarButtonInicioSesion = new Button();
            CrearCuentaButton = new Button();
            Texto2InicioSesion = new Label();
            TextoInicioSesion = new Label();
            AutorellenarDatosButtonSesion = new Button();
            SuspendLayout();
            // 
            // TituloInicioSesion
            // 
            TituloInicioSesion.AutoSize = true;
            TituloInicioSesion.Font = new Font("Bodoni MT", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TituloInicioSesion.Location = new Point(296, 52);
            TituloInicioSesion.Name = "TituloInicioSesion";
            TituloInicioSesion.Size = new Size(217, 27);
            TituloInicioSesion.TabIndex = 0;
            TituloInicioSesion.Text = "INICIO DE SESIÓN";
            // 
            // UsuarioTextBox
            // 
            UsuarioTextBox.Location = new Point(336, 132);
            UsuarioTextBox.Name = "UsuarioTextBox";
            UsuarioTextBox.Size = new Size(177, 27);
            UsuarioTextBox.TabIndex = 1;
            // 
            // ContraseñaTextBox
            // 
            ContraseñaTextBox.Location = new Point(336, 182);
            ContraseñaTextBox.Name = "ContraseñaTextBox";
            ContraseñaTextBox.Size = new Size(177, 27);
            ContraseñaTextBox.TabIndex = 2;
            // 
            // UsuarioLabel
            // 
            UsuarioLabel.AutoSize = true;
            UsuarioLabel.Location = new Point(268, 135);
            UsuarioLabel.Name = "UsuarioLabel";
            UsuarioLabel.Size = new Size(62, 20);
            UsuarioLabel.TabIndex = 3;
            UsuarioLabel.Text = "Usuario:";
            // 
            // ContraseñaLabel
            // 
            ContraseñaLabel.AutoSize = true;
            ContraseñaLabel.Location = new Point(244, 185);
            ContraseñaLabel.Name = "ContraseñaLabel";
            ContraseñaLabel.Size = new Size(86, 20);
            ContraseñaLabel.TabIndex = 4;
            ContraseñaLabel.Text = "Contraseña:";
            // 
            // AceptarButtonInicioSesion
            // 
            AceptarButtonInicioSesion.FlatAppearance.BorderColor = Color.Black;
            AceptarButtonInicioSesion.Location = new Point(363, 259);
            AceptarButtonInicioSesion.Name = "AceptarButtonInicioSesion";
            AceptarButtonInicioSesion.Size = new Size(94, 29);
            AceptarButtonInicioSesion.TabIndex = 5;
            AceptarButtonInicioSesion.Text = "Aceptar";
            AceptarButtonInicioSesion.UseVisualStyleBackColor = true;
            AceptarButtonInicioSesion.Click += AceptarButtonInicioSesion_Click;
            // 
            // CrearCuentaButton
            // 
            CrearCuentaButton.Location = new Point(348, 329);
            CrearCuentaButton.Name = "CrearCuentaButton";
            CrearCuentaButton.Size = new Size(125, 29);
            CrearCuentaButton.TabIndex = 6;
            CrearCuentaButton.Text = "Crear cuenta";
            CrearCuentaButton.UseVisualStyleBackColor = true;
            CrearCuentaButton.Click += CrearCuentaButton_Click;
            // 
            // Texto2InicioSesion
            // 
            Texto2InicioSesion.AutoSize = true;
            Texto2InicioSesion.Location = new Point(256, 306);
            Texto2InicioSesion.Name = "Texto2InicioSesion";
            Texto2InicioSesion.Size = new Size(307, 20);
            Texto2InicioSesion.TabIndex = 8;
            Texto2InicioSesion.Text = "No tienes cuenta todavía? Create una cuenta.";
            // 
            // TextoInicioSesion
            // 
            TextoInicioSesion.AutoSize = true;
            TextoInicioSesion.Font = new Font("Calibri", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TextoInicioSesion.Location = new Point(155, 79);
            TextoInicioSesion.Name = "TextoInicioSesion";
            TextoInicioSesion.Size = new Size(535, 21);
            TextoInicioSesion.TabIndex = 9;
            TextoInicioSesion.Text = "Introduzca su nombre de usuario y su contraseña para acceder al simulador";
            // 
            // AutorellenarDatosButtonSesion
            // 
            AutorellenarDatosButtonSesion.Location = new Point(326, 224);
            AutorellenarDatosButtonSesion.Name = "AutorellenarDatosButtonSesion";
            AutorellenarDatosButtonSesion.Size = new Size(162, 29);
            AutorellenarDatosButtonSesion.TabIndex = 10;
            AutorellenarDatosButtonSesion.Text = "Autorellenar Datos";
            AutorellenarDatosButtonSesion.UseVisualStyleBackColor = true;
            AutorellenarDatosButtonSesion.Click += AutorellenarDatosButtonSesion_Click;
            // 
            // InicioSesion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(AutorellenarDatosButtonSesion);
            Controls.Add(TextoInicioSesion);
            Controls.Add(Texto2InicioSesion);
            Controls.Add(CrearCuentaButton);
            Controls.Add(AceptarButtonInicioSesion);
            Controls.Add(ContraseñaLabel);
            Controls.Add(UsuarioLabel);
            Controls.Add(ContraseñaTextBox);
            Controls.Add(UsuarioTextBox);
            Controls.Add(TituloInicioSesion);
            Name = "InicioSesion";
            Text = "InicioSesion";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label TituloInicioSesion;
        private TextBox UsuarioTextBox;
        private TextBox ContraseñaTextBox;
        private Label UsuarioLabel;
        private Label ContraseñaLabel;
        private Button AceptarButtonInicioSesion;
        private Button CrearCuentaButton;
        private Label Texto2InicioSesion;
        private Label TextoInicioSesion;
        private Button AutorellenarDatosButtonSesion;
    }
}