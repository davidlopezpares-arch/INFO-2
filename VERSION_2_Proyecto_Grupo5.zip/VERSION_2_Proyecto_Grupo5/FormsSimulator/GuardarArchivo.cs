﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace FormsSimulator
{
    public partial class GuardarArchivo : Form
    {
        public GuardarArchivo()
        {
            InitializeComponent();
        }

        FlightPlanList milista = new FlightPlanList();
        public void SetLista(FlightPlanList lista)
        {
            this.milista = lista;
        }


        private void aceptarButton_Click(object sender, EventArgs e)
        {
            if (nombreTextBox.Text == "")
            {
                MessageBox.Show("Escribe un nombre para el archivo");
                return;
            }

            if (milista == null || milista.GetNumFlightPlans() == 0)
            {
                MessageBox.Show("No hay planes de vuelo para guardar");
                return;
            }

            string nombre = nombreTextBox.Text;

            try
            {
                using (StreamWriter w = new StreamWriter(nombre))
                {
                    int i = 0;

                    while (i < milista.GetNumFlightPlans())
                    {
                        FlightPlan p = milista.GetFlightPlan(i);

                        w.WriteLine(p.GetId() + " " +
                            p.GetCompañia() + " " +
                            p.GetCurrentPosition().GetX() + " " +
                            p.GetCurrentPosition().GetY() + " " +
                            p.GetFinalPosition().GetX() + " " +
                            p.GetFinalPosition().GetY() + " " +
                            p.GetVelocidad());

                        i = i + 1;
                    }
                }

                MessageBox.Show("Se ha guardado la simulación correctamente en el archivo " + nombre);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el archivo: " + ex.Message);
            }
        }


        private void volveratrasButton_Click(object sender, EventArgs e)
        {
            this.Close();  
        }
    }
}

