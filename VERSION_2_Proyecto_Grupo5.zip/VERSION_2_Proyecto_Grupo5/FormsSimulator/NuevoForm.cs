﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FlightLib;

namespace FormsSimulator
{
    public partial class NuevoForm : Form
    {
        FlightPlanList milista = new FlightPlanList();
        public NuevoForm()
        {
            InitializeComponent();
        }
        public FlightPlanList GetLista()
        {
            if (milista.GetNumFlightPlans() == 0)
            {
                MessageBox.Show("No se han agregado vuelos");
                return null;
            }
            else
                return this.milista;
        }

        private void Aceptarbutton_Click(object sender, EventArgs e)
        {
            try
            {
                string[] linia1 = PosicionInicial1.Text.Split(',');
                double X1 = Convert.ToDouble(linia1[0]);
                double Y1 = Convert.ToDouble(linia1[1]);
                string[] linia2 = PosicionFinal1.Text.Split(',');
                double X2 = Convert.ToDouble(linia2[0]);
                double Y2 = Convert.ToDouble(linia2[1]);
                double velodidad1 = Convert.ToDouble(Velocidad1.Text);
                string[] linia3 = PosicionInicial2.Text.Split(',');
                double X3 = Convert.ToDouble(linia3[0]);
                double Y3 = Convert.ToDouble(linia3[1]);
                string[] linia4 = PosicionFinal2.Text.Split(',');
                double X4 = Convert.ToDouble(linia4[0]);
                double Y4 = Convert.ToDouble(linia4[1]);
                double velodidad2 = Convert.ToDouble(Velocidad2.Text);
                if (X1 < 0 || Y1 < 0 || X2 < 0 || Y2 < 0 || velodidad1 <= 0 || X3 < 0 || Y3 < 0 || X4 < 0 || Y4 < 0 || velodidad2 <= 0 || Compania1.Text == "" || Compania2.Text == "")
                {
                    MessageBox.Show("Error: Introduce bien los datos");
                }
                else
                {
                    FlightPlan A = new FlightPlan(Id1.Text, Compania1.Text, X1, Y1, X2, Y2, velodidad1);
                    milista.AddFlightPlan(A);
                    FlightPlan B = new FlightPlan(Id2.Text, Compania2.Text, X3, Y3, X4, Y4, velodidad2);
                    milista.AddFlightPlan(B);
                    Close();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Error: Introduce bien los datos");
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Error: Introduce bien los datos");
            }


        }

        private void AutorellenarBoton_Click(object sender, EventArgs e)
        {
            PosicionInicial1.Text = "0,0";
            PosicionFinal1.Text = "100,100";
            Velocidad1.Text = "10";
            PosicionInicial2.Text = "100,0";
            PosicionFinal2.Text = "0,100";
            Velocidad2.Text = "10";
            Id1.Text = "A";
            Id2.Text = "B";
            Compania1.Text = "Iberia";
            Compania2.Text = "Vueling";
        }

        private void VolverAtrasNuevoForm_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
