﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FormsSimulator
{
    public partial class InicioSesion : Form
    {
        public InicioSesion()
        {
            InitializeComponent();
        }
        private void InicioSesion_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Bienvenido a nuestro proyecto de informática, un simulador de vuelo. Por favor, inicie sesión para continuar y acceder al simulador.");
        }

        private void AceptarButtonInicioSesion_Click(object sender, EventArgs e)
        {
            try
            {
                string usuario = UsuarioTextBox.Text;
                string contraseña = ContraseñaTextBox.Text;
                // Tendriamos que poner un if para comprobar si el usuario y la contraseña son correctos,
                // pero como no tenemos base de datos aun, vamos a asumir que cualquier usuario y contraseña son correctos.
                MessageBox.Show("Usuario y contraseña introducidos correctamente. Accediendo al simulador...");
                Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Error al introducir los datos");
            }
        }

        private void CrearCuentaButton_Click(object sender, EventArgs e)
        {
            CrearCuenta Form = new CrearCuenta();
            Form.SetUsuario(UsuarioTextBox.Text);
            Form.SetContraseña(ContraseñaTextBox.Text);
            Form.ShowDialog();
            if (Form.GetUsuario() != null || Form.GetContraseña() != null)
            {
                UsuarioTextBox.Text = Form.GetUsuario();
            }
        }

        private void AutorellenarDatosButtonSesion_Click(object sender, EventArgs e)
        {
            UsuarioTextBox.Text = "Grupo5";
            ContraseñaTextBox.Text = "Simulador123";
        }
    }
}
