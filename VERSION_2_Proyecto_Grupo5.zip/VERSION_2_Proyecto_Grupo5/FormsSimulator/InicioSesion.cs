﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Gestor;   

namespace FormsSimulator
{
    public partial class InicioSesion : Form
    {
        GestorBBDD mi_base = new GestorBBDD();
        public InicioSesion()
        {
            InitializeComponent();
        }
        private void InicioSesion_Load(object sender, EventArgs e)
        {
            mi_base.Iniciar();
            MessageBox.Show("Bienvenido a nuestro proyecto de informática, un simulador de vuelo. Por favor, inicie sesión para continuar y acceder al simulador.");
        }

        private void AceptarButtonInicioSesion_Click(object sender, EventArgs e)
        {
            string usuario = UsuarioTextBox.Text;
            string contraseña = ContraseñaTextBox.Text;

            if (usuario != "" && contraseña != "")
            {
                if (mi_base.ValidarUsuario(usuario, contraseña))
                {
                    MessageBox.Show("Usuario y contraseña correctos. Accediendo al simulador...");
                    mi_base.Cerrar();
                    Close();
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, introduzca el usuario y la contraseña.");
            }
        }

        private void CrearCuentaButton_Click(object sender, EventArgs e)
        {
            CrearCuenta Form = new CrearCuenta();
            Form.SetUsuario(UsuarioTextBox.Text);
            Form.SetContraseña(ContraseñaTextBox.Text);
            Form.ShowDialog();
            if (Form.GetUsuario() != null || Form.GetContraseña() != null)
            {
                UsuarioTextBox.Text = Form.GetUsuario();
            }
        }

        private void AutorellenarDatosButtonSesion_Click(object sender, EventArgs e)
        {
            UsuarioTextBox.Text = "Grupo5";
            ContraseñaTextBox.Text = "Simulador123";
        }
    }
}
