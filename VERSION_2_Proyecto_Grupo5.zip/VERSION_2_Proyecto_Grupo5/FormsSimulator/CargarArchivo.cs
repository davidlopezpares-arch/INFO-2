﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
    
namespace FormsSimulator
{
    public partial class CargarArchivo : Form
    {
        public CargarArchivo()
        {
            InitializeComponent();
        }
        FlightPlanList milista = new FlightPlanList();
        public FlightPlanList GetLista()
        {
            return milista;
        }
        private void aceptarButton_Click(object sender, EventArgs e)
        {
            if (nombreTextBox == null || nombreTextBox.Text == "")
            {
                MessageBox.Show("Escribe un nombre para el archivo");
                return;
            }
            string nombre = nombreTextBox.Text;

            try
            {
                StreamReader r = new StreamReader(nombre);
                string linea = r.ReadLine();

                while (linea != null)
                {
                    string[] datos = linea.Split(" ");

                    string id = datos[0];
                    double cpx = Convert.ToDouble(datos[1]);
                    double cpy = Convert.ToDouble(datos[2]);
                    double fpx = Convert.ToDouble(datos[3]);
                    double fpy = Convert.ToDouble(datos[4]);
                    double velocidad = Convert.ToDouble(datos[5]);

                    FlightPlan plan = new FlightPlan(id, cpx, cpy, fpx, fpy, velocidad);

                    milista.AddFlightPlan(plan);

                    linea = r.ReadLine();
                }

                r.Close();
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Archivo no encontrado");
                return;
            }
            catch (FormatException)
            {
                MessageBox.Show("Error en el formato de los datos del archivo");
                return;
            }

            this.Close();
        }
        

        private void vovleratrasButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
