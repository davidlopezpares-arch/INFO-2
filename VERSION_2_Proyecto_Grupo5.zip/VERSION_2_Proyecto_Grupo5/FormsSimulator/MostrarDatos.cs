﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Numerics;
using System.Text;
using System.Windows.Forms;

namespace FormsSimulator
{
    public partial class MostrarDatos : Form
    {
        FlightPlanList milista;
        public MostrarDatos()
        {
            InitializeComponent();
        }
        public void SetLista(FlightPlanList milista)
        {
            this.milista = milista;
        }
        private void MostrarDatos_Load(object sender, EventArgs e)
        {
            Matriz.RowCount = 9;
            Matriz.ColumnCount = milista.GetNumFlightPlans() + 1;
            Matriz.Enabled = true;
            Matriz.ReadOnly = true;
            Matriz.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            Matriz.Rows[0].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[0].Cells[0].Value = "Identificador";
            Matriz.Rows[1].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[1].Cells[0].Value = "X inicial";
            Matriz.Rows[2].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[2].Cells[0].Value = "Y inicial";
            Matriz.Rows[3].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[3].Cells[0].Value = "X actual";
            Matriz.Rows[4].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[4].Cells[0].Value = "Y actual";
            Matriz.Rows[5].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[5].Cells[0].Value = "X final";
            Matriz.Rows[6].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[6].Cells[0].Value = "Y final";
            Matriz.Rows[7].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[7].Cells[0].Value = "Velocidad";
            Matriz.Rows[8].Cells[0] = new DataGridViewTextBoxCell();
            Matriz.Rows[8].Cells[0].Value = "Compañía";
            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                FlightPlan plan = milista.GetFlightPlan(i);
                Matriz.Rows[0].Cells[i + 1].Value = plan.GetId();
                Matriz.Rows[1].Cells[i + 1].Value = plan.GetInitialPosition().GetX();
                Matriz.Rows[2].Cells[i + 1].Value = plan.GetInitialPosition().GetY();
                Matriz.Rows[3].Cells[i + 1].Value = plan.GetCurrentPosition().GetX();
                Matriz.Rows[4].Cells[i + 1].Value = plan.GetCurrentPosition().GetY();
                Matriz.Rows[5].Cells[i + 1].Value = plan.GetFinalPosition().GetX();
                Matriz.Rows[6].Cells[i + 1].Value = plan.GetFinalPosition().GetY();
                Matriz.Rows[7].Cells[i + 1].Value = plan.GetVelocidad();
                Matriz.Rows[8].Cells[i + 1].Value = plan.GetCompañia();
            }
        }


        private void Matriz_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex < 1 || e.ColumnIndex > milista.GetNumFlightPlans())
            {
                MessageBox.Show("Seleccione un vuelo");
                return;
            }

            int vuelo = e.ColumnIndex - 1;
            string mensaje = "";

            for (int i = 0; i < milista.GetNumFlightPlans(); i++)
            {
                if (i != vuelo)
                {
                    double distancia = milista.GetFlightPlan(vuelo).Distancia(milista.GetFlightPlan(i));

                    mensaje = mensaje + "Vuelo " + milista.GetFlightPlan(i).GetId() + ": " + distancia.ToString("F2") + "\n";
                }
            }

            DistanciaVuelos f1 = new DistanciaVuelos();
            f1.SetDistancia(mensaje);
            f1.ShowDialog();
        }



        private void VolverAtrasBoton_MostrarDatos_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
