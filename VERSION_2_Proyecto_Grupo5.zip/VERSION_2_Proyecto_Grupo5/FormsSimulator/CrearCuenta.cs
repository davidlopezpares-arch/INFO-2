﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FormsSimulator
{
    public partial class CrearCuenta : Form
    {
        public CrearCuenta()
        {
            InitializeComponent();
        }
        public void SetUsuario(string usuario)
        {
            UsuarioNuevoTextBox.Text = usuario;
        }
        public void SetContraseña(string contraseña)
        {
            ContraseñaNuevaTextBox.Text = contraseña;
        }
        public string GetUsuario()
        {
            return UsuarioNuevoTextBox.Text;
        }
        public string GetContraseña()
        {
            return ContraseñaNuevaTextBox.Text;
        }

        private void AceptarButtonCrearCuenta_Click(object sender, EventArgs e)
        {
            if (ContraseñaNuevaTextBox.Text == RepiteContraseñaTextBox.Text)
            {
                try
                {
                    if(UsuarioNuevoTextBox.Text != "" && ContraseñaNuevaTextBox.Text != "")
                    {
                        string usuario = UsuarioNuevoTextBox.Text;
                        string contraseña = ContraseñaNuevaTextBox.Text;
                        // Repetimos, aqui habria que comprobar si el usuario ya existe, pero como no tenemos base de datos aun,
                        // vamos a asumir que cualquier usuario y contraseña son correctos. Y si no existe, lo añadimos a la base de datos.
                        MessageBox.Show("Cuenta creada correctamente. Ahora puede iniciar sesión con su nueva cuenta.");
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Por favor, rellene todos los campos.");
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Error al introducir los datos");
                }
            }
            else
            {
                MessageBox.Show("Las contraseñas no coinciden. Por favor, inténtelo de nuevo.");
            }
        }

        private void VolverAtrasCrearCuenta_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
