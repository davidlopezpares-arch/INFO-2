﻿namespace FormsSimulator
{
    partial class CrearCuenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CrearCuentaTitulo = new Label();
            AceptarButtonCrearCuenta = new Button();
            ContraseñaNuevaLabel = new Label();
            UsuarioNuevoLabel = new Label();
            ContraseñaNuevaTextBox = new TextBox();
            UsuarioNuevoTextBox = new TextBox();
            RepiteContraseñaLabel = new Label();
            RepiteContraseñaTextBox = new TextBox();
            VolverAtrasCrearCuenta = new Button();
            TextoCrearCuenta = new Label();
            SuspendLayout();
            // 
            // CrearCuentaTitulo
            // 
            CrearCuentaTitulo.AutoSize = true;
            CrearCuentaTitulo.Font = new Font("Bodoni MT", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CrearCuentaTitulo.Location = new Point(281, 42);
            CrearCuentaTitulo.Name = "CrearCuentaTitulo";
            CrearCuentaTitulo.Size = new Size(232, 27);
            CrearCuentaTitulo.TabIndex = 1;
            CrearCuentaTitulo.Text = "CREA UNA CUENTA";
            // 
            // AceptarButtonCrearCuenta
            // 
            AceptarButtonCrearCuenta.FlatAppearance.BorderColor = Color.Black;
            AceptarButtonCrearCuenta.Location = new Point(358, 252);
            AceptarButtonCrearCuenta.Name = "AceptarButtonCrearCuenta";
            AceptarButtonCrearCuenta.Size = new Size(94, 29);
            AceptarButtonCrearCuenta.TabIndex = 10;
            AceptarButtonCrearCuenta.Text = "Aceptar";
            AceptarButtonCrearCuenta.UseVisualStyleBackColor = true;
            AceptarButtonCrearCuenta.Click += AceptarButtonCrearCuenta_Click;
            // 
            // ContraseñaNuevaLabel
            // 
            ContraseñaNuevaLabel.AutoSize = true;
            ContraseñaNuevaLabel.Location = new Point(244, 163);
            ContraseñaNuevaLabel.Name = "ContraseñaNuevaLabel";
            ContraseñaNuevaLabel.Size = new Size(86, 20);
            ContraseñaNuevaLabel.TabIndex = 9;
            ContraseñaNuevaLabel.Text = "Contraseña:";
            // 
            // UsuarioNuevoLabel
            // 
            UsuarioNuevoLabel.AutoSize = true;
            UsuarioNuevoLabel.Location = new Point(268, 113);
            UsuarioNuevoLabel.Name = "UsuarioNuevoLabel";
            UsuarioNuevoLabel.Size = new Size(62, 20);
            UsuarioNuevoLabel.TabIndex = 8;
            UsuarioNuevoLabel.Text = "Usuario:";
            // 
            // ContraseñaNuevaTextBox
            // 
            ContraseñaNuevaTextBox.Location = new Point(336, 160);
            ContraseñaNuevaTextBox.Name = "ContraseñaNuevaTextBox";
            ContraseñaNuevaTextBox.Size = new Size(177, 27);
            ContraseñaNuevaTextBox.TabIndex = 7;
            // 
            // UsuarioNuevoTextBox
            // 
            UsuarioNuevoTextBox.Location = new Point(336, 110);
            UsuarioNuevoTextBox.Name = "UsuarioNuevoTextBox";
            UsuarioNuevoTextBox.Size = new Size(177, 27);
            UsuarioNuevoTextBox.TabIndex = 6;
            // 
            // RepiteContraseñaLabel
            // 
            RepiteContraseñaLabel.AutoSize = true;
            RepiteContraseñaLabel.Location = new Point(183, 208);
            RepiteContraseñaLabel.Name = "RepiteContraseñaLabel";
            RepiteContraseñaLabel.Size = new Size(147, 20);
            RepiteContraseñaLabel.TabIndex = 12;
            RepiteContraseñaLabel.Text = "Repite la contraseña:";
            // 
            // RepiteContraseñaTextBox
            // 
            RepiteContraseñaTextBox.Location = new Point(336, 205);
            RepiteContraseñaTextBox.Name = "RepiteContraseñaTextBox";
            RepiteContraseñaTextBox.Size = new Size(177, 27);
            RepiteContraseñaTextBox.TabIndex = 11;
            // 
            // VolverAtrasCrearCuenta
            // 
            VolverAtrasCrearCuenta.Location = new Point(346, 322);
            VolverAtrasCrearCuenta.Name = "VolverAtrasCrearCuenta";
            VolverAtrasCrearCuenta.Size = new Size(117, 29);
            VolverAtrasCrearCuenta.TabIndex = 13;
            VolverAtrasCrearCuenta.Text = "Volver atrás";
            VolverAtrasCrearCuenta.UseVisualStyleBackColor = true;
            VolverAtrasCrearCuenta.Click += VolverAtrasCrearCuenta_Click;
            // 
            // TextoCrearCuenta
            // 
            TextoCrearCuenta.AutoSize = true;
            TextoCrearCuenta.Location = new Point(268, 299);
            TextoCrearCuenta.Name = "TextoCrearCuenta";
            TextoCrearCuenta.Size = new Size(307, 20);
            TextoCrearCuenta.TabIndex = 14;
            TextoCrearCuenta.Text = "No tienes cuenta todavía? Create una cuenta.";
            // 
            // CrearCuenta
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(TextoCrearCuenta);
            Controls.Add(VolverAtrasCrearCuenta);
            Controls.Add(RepiteContraseñaLabel);
            Controls.Add(RepiteContraseñaTextBox);
            Controls.Add(AceptarButtonCrearCuenta);
            Controls.Add(ContraseñaNuevaLabel);
            Controls.Add(UsuarioNuevoLabel);
            Controls.Add(ContraseñaNuevaTextBox);
            Controls.Add(UsuarioNuevoTextBox);
            Controls.Add(CrearCuentaTitulo);
            Name = "CrearCuenta";
            Text = "CrearCuenta";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label CrearCuentaTitulo;
        private Button AceptarButtonCrearCuenta;
        private Label ContraseñaNuevaLabel;
        private Label UsuarioNuevoLabel;
        private TextBox ContraseñaNuevaTextBox;
        private TextBox UsuarioNuevoTextBox;
        private Label RepiteContraseñaLabel;
        private TextBox RepiteContraseñaTextBox;
        private Button VolverAtrasCrearCuenta;
        private Label TextoCrearCuenta;
    }
}