﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class InicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TituloInicioSesion = new System.Windows.Forms.Label();
            this.UsuarioTextBox = new System.Windows.Forms.TextBox();
            this.ContraseñaTextBox = new System.Windows.Forms.TextBox();
            this.UsuarioLabel = new System.Windows.Forms.Label();
            this.ContraseñaLabel = new System.Windows.Forms.Label();
            this.AceptarButtonInicioSesion = new System.Windows.Forms.Button();
            this.CrearCuentaButton = new System.Windows.Forms.Button();
            this.Texto2InicioSesion = new System.Windows.Forms.Label();
            this.TextoInicioSesion = new System.Windows.Forms.Label();
            this.AutorellenarDatosButtonSesion = new System.Windows.Forms.Button();
            this.CerrarButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TituloInicioSesion
            // 
            this.TituloInicioSesion.AutoSize = true;
            this.TituloInicioSesion.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TituloInicioSesion.Location = new System.Drawing.Point(333, 52);
            this.TituloInicioSesion.Name = "TituloInicioSesion";
            this.TituloInicioSesion.Size = new System.Drawing.Size(267, 34);
            this.TituloInicioSesion.TabIndex = 0;
            this.TituloInicioSesion.Text = "INICIO DE SESIÓN";
            // 
            // UsuarioTextBox
            // 
            this.UsuarioTextBox.Location = new System.Drawing.Point(378, 132);
            this.UsuarioTextBox.Name = "UsuarioTextBox";
            this.UsuarioTextBox.Size = new System.Drawing.Size(199, 26);
            this.UsuarioTextBox.TabIndex = 1;
            // 
            // ContraseñaTextBox
            // 
            this.ContraseñaTextBox.Location = new System.Drawing.Point(378, 182);
            this.ContraseñaTextBox.Name = "ContraseñaTextBox";
            this.ContraseñaTextBox.Size = new System.Drawing.Size(199, 26);
            this.ContraseñaTextBox.TabIndex = 2;
            // 
            // UsuarioLabel
            // 
            this.UsuarioLabel.AutoSize = true;
            this.UsuarioLabel.Location = new System.Drawing.Point(302, 135);
            this.UsuarioLabel.Name = "UsuarioLabel";
            this.UsuarioLabel.Size = new System.Drawing.Size(68, 20);
            this.UsuarioLabel.TabIndex = 3;
            this.UsuarioLabel.Text = "Usuario:";
            // 
            // ContraseñaLabel
            // 
            this.ContraseñaLabel.AutoSize = true;
            this.ContraseñaLabel.Location = new System.Drawing.Point(274, 185);
            this.ContraseñaLabel.Name = "ContraseñaLabel";
            this.ContraseñaLabel.Size = new System.Drawing.Size(96, 20);
            this.ContraseñaLabel.TabIndex = 4;
            this.ContraseñaLabel.Text = "Contraseña:";
            // 
            // AceptarButtonInicioSesion
            // 
            this.AceptarButtonInicioSesion.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.AceptarButtonInicioSesion.Location = new System.Drawing.Point(378, 293);
            this.AceptarButtonInicioSesion.Name = "AceptarButtonInicioSesion";
            this.AceptarButtonInicioSesion.Size = new System.Drawing.Size(150, 50);
            this.AceptarButtonInicioSesion.TabIndex = 5;
            this.AceptarButtonInicioSesion.Text = "Aceptar";
            this.AceptarButtonInicioSesion.UseVisualStyleBackColor = true;
            this.AceptarButtonInicioSesion.Click += new System.EventHandler(this.AceptarButtonInicioSesion_Click);
            // 
            // CrearCuentaButton
            // 
            this.CrearCuentaButton.Location = new System.Drawing.Point(378, 392);
            this.CrearCuentaButton.Name = "CrearCuentaButton";
            this.CrearCuentaButton.Size = new System.Drawing.Size(150, 50);
            this.CrearCuentaButton.TabIndex = 6;
            this.CrearCuentaButton.Text = "Crear cuenta";
            this.CrearCuentaButton.UseVisualStyleBackColor = true;
            this.CrearCuentaButton.Click += new System.EventHandler(this.CrearCuentaButton_Click);
            // 
            // Texto2InicioSesion
            // 
            this.Texto2InicioSesion.AutoSize = true;
            this.Texto2InicioSesion.Location = new System.Drawing.Point(289, 357);
            this.Texto2InicioSesion.Name = "Texto2InicioSesion";
            this.Texto2InicioSesion.Size = new System.Drawing.Size(333, 20);
            this.Texto2InicioSesion.TabIndex = 8;
            this.Texto2InicioSesion.Text = "No tienes cuenta todavía? Create una cuenta.";
            // 
            // TextoInicioSesion
            // 
            this.TextoInicioSesion.AutoSize = true;
            this.TextoInicioSesion.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoInicioSesion.Location = new System.Drawing.Point(174, 79);
            this.TextoInicioSesion.Name = "TextoInicioSesion";
            this.TextoInicioSesion.Size = new System.Drawing.Size(654, 26);
            this.TextoInicioSesion.TabIndex = 9;
            this.TextoInicioSesion.Text = "Introduzca su nombre de usuario y su contraseña para acceder al simulador";
            // 
            // AutorellenarDatosButtonSesion
            // 
            this.AutorellenarDatosButtonSesion.Location = new System.Drawing.Point(378, 224);
            this.AutorellenarDatosButtonSesion.Name = "AutorellenarDatosButtonSesion";
            this.AutorellenarDatosButtonSesion.Size = new System.Drawing.Size(150, 63);
            this.AutorellenarDatosButtonSesion.TabIndex = 10;
            this.AutorellenarDatosButtonSesion.Text = "Autorellenar Datos";
            this.AutorellenarDatosButtonSesion.UseVisualStyleBackColor = true;
            this.AutorellenarDatosButtonSesion.Click += new System.EventHandler(this.AutorellenarDatosButtonSesion_Click);
            // 
            // CerrarButton
            // 
            this.CerrarButton.Location = new System.Drawing.Point(375, 496);
            this.CerrarButton.Name = "CerrarButton";
            this.CerrarButton.Size = new System.Drawing.Size(153, 35);
            this.CerrarButton.TabIndex = 11;
            this.CerrarButton.Text = "Cerrar Formulario";
            this.CerrarButton.UseVisualStyleBackColor = true;
            this.CerrarButton.Click += new System.EventHandler(this.CerrarButton_Click);
            // 
            // InicioSesion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.CerrarButton);
            this.Controls.Add(this.AutorellenarDatosButtonSesion);
            this.Controls.Add(this.TextoInicioSesion);
            this.Controls.Add(this.Texto2InicioSesion);
            this.Controls.Add(this.CrearCuentaButton);
            this.Controls.Add(this.AceptarButtonInicioSesion);
            this.Controls.Add(this.ContraseñaLabel);
            this.Controls.Add(this.UsuarioLabel);
            this.Controls.Add(this.ContraseñaTextBox);
            this.Controls.Add(this.UsuarioTextBox);
            this.Controls.Add(this.TituloInicioSesion);
            this.Name = "InicioSesion";
            this.Text = "InicioSesion";
            this.Load += new System.EventHandler(this.InicioSesion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label TituloInicioSesion;
        private TextBox UsuarioTextBox;
        private TextBox ContraseñaTextBox;
        private Label UsuarioLabel;
        private Label ContraseñaLabel;
        private Button AceptarButtonInicioSesion;
        private Button CrearCuentaButton;
        private Label Texto2InicioSesion;
        private Label TextoInicioSesion;
        private Button AutorellenarDatosButtonSesion;
        private Button CerrarButton;
    }
}