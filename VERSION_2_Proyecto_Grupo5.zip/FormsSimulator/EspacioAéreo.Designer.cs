﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class EspacioAéreo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Moverbutton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Automáticobutton = new System.Windows.Forms.Button();
            this.MostarDatosButton = new System.Windows.Forms.Button();
            this.Conflicto = new System.Windows.Forms.Button();
            this.VolverAtrasBoton_EspacioAereo = new System.Windows.Forms.Button();
            this.CambiarVelocidad = new System.Windows.Forms.Button();
            this.Restart = new System.Windows.Forms.Button();
            this.PuntoAnteriorButton = new System.Windows.Forms.Button();
            this.guardarButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Location = new System.Drawing.Point(226, 22);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(941, 633);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Moverbutton
            // 
            this.Moverbutton.Location = new System.Drawing.Point(52, 94);
            this.Moverbutton.Margin = new System.Windows.Forms.Padding(2);
            this.Moverbutton.Name = "Moverbutton";
            this.Moverbutton.Size = new System.Drawing.Size(150, 50);
            this.Moverbutton.TabIndex = 1;
            this.Moverbutton.Text = "Mover";
            this.Moverbutton.UseVisualStyleBackColor = true;
            this.Moverbutton.Click += new System.EventHandler(this.Moverbutton_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Automáticobutton
            // 
            this.Automáticobutton.Location = new System.Drawing.Point(52, 160);
            this.Automáticobutton.Margin = new System.Windows.Forms.Padding(2);
            this.Automáticobutton.Name = "Automáticobutton";
            this.Automáticobutton.Size = new System.Drawing.Size(150, 50);
            this.Automáticobutton.TabIndex = 2;
            this.Automáticobutton.Text = "Automático";
            this.Automáticobutton.UseVisualStyleBackColor = true;
            this.Automáticobutton.Click += new System.EventHandler(this.Automáticobutton_Click);
            // 
            // MostarDatosButton
            // 
            this.MostarDatosButton.Location = new System.Drawing.Point(52, 30);
            this.MostarDatosButton.Margin = new System.Windows.Forms.Padding(2);
            this.MostarDatosButton.Name = "MostarDatosButton";
            this.MostarDatosButton.Size = new System.Drawing.Size(150, 50);
            this.MostarDatosButton.TabIndex = 3;
            this.MostarDatosButton.Text = "Mostrar Datos";
            this.MostarDatosButton.UseVisualStyleBackColor = true;
            this.MostarDatosButton.Click += new System.EventHandler(this.MostarDatosButton_Click);
            // 
            // Conflicto
            // 
            this.Conflicto.Location = new System.Drawing.Point(52, 229);
            this.Conflicto.Margin = new System.Windows.Forms.Padding(2);
            this.Conflicto.Name = "Conflicto";
            this.Conflicto.Size = new System.Drawing.Size(150, 63);
            this.Conflicto.TabIndex = 4;
            this.Conflicto.Text = "Comprobar Conflicto";
            this.Conflicto.UseVisualStyleBackColor = true;
            this.Conflicto.Click += new System.EventHandler(this.Conflicto_Click);
            // 
            // VolverAtrasBoton_EspacioAereo
            // 
            this.VolverAtrasBoton_EspacioAereo.Location = new System.Drawing.Point(52, 626);
            this.VolverAtrasBoton_EspacioAereo.Name = "VolverAtrasBoton_EspacioAereo";
            this.VolverAtrasBoton_EspacioAereo.Size = new System.Drawing.Size(150, 29);
            this.VolverAtrasBoton_EspacioAereo.TabIndex = 5;
            this.VolverAtrasBoton_EspacioAereo.Text = "Volver atrás";
            this.VolverAtrasBoton_EspacioAereo.UseVisualStyleBackColor = true;
            this.VolverAtrasBoton_EspacioAereo.Click += new System.EventHandler(this.VolverAtrasBoton_EspacioAereo_Click);
            // 
            // CambiarVelocidad
            // 
            this.CambiarVelocidad.Location = new System.Drawing.Point(52, 307);
            this.CambiarVelocidad.Margin = new System.Windows.Forms.Padding(2);
            this.CambiarVelocidad.Name = "CambiarVelocidad";
            this.CambiarVelocidad.Size = new System.Drawing.Size(150, 56);
            this.CambiarVelocidad.TabIndex = 6;
            this.CambiarVelocidad.Text = "Cambiar velocidad";
            this.CambiarVelocidad.UseVisualStyleBackColor = true;
            this.CambiarVelocidad.Click += new System.EventHandler(this.CambiarVelocidad_Click);
            // 
            // Restart
            // 
            this.Restart.Location = new System.Drawing.Point(52, 376);
            this.Restart.Margin = new System.Windows.Forms.Padding(2);
            this.Restart.Name = "Restart";
            this.Restart.Size = new System.Drawing.Size(150, 50);
            this.Restart.TabIndex = 7;
            this.Restart.Text = "Restart";
            this.Restart.UseVisualStyleBackColor = true;
            this.Restart.Click += new System.EventHandler(this.Restart_Click);
            // 
            // PuntoAnteriorButton
            // 
            this.PuntoAnteriorButton.Location = new System.Drawing.Point(52, 440);
            this.PuntoAnteriorButton.Margin = new System.Windows.Forms.Padding(2);
            this.PuntoAnteriorButton.Name = "PuntoAnteriorButton";
            this.PuntoAnteriorButton.Size = new System.Drawing.Size(150, 63);
            this.PuntoAnteriorButton.TabIndex = 8;
            this.PuntoAnteriorButton.Text = "Posición anterior";
            this.PuntoAnteriorButton.UseVisualStyleBackColor = true;
            this.PuntoAnteriorButton.Click += new System.EventHandler(this.PuntoAnteriorButton_Click);
            // 
            // guardarButton
            // 
            this.guardarButton.Location = new System.Drawing.Point(52, 518);
            this.guardarButton.Name = "guardarButton";
            this.guardarButton.Size = new System.Drawing.Size(150, 63);
            this.guardarButton.TabIndex = 9;
            this.guardarButton.Text = "Guardar  Simulación";
            this.guardarButton.UseVisualStyleBackColor = true;
            this.guardarButton.Click += new System.EventHandler(this.guardarButton_Click);
            // 
            // EspacioAéreo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 694);
            this.Controls.Add(this.guardarButton);
            this.Controls.Add(this.PuntoAnteriorButton);
            this.Controls.Add(this.Restart);
            this.Controls.Add(this.CambiarVelocidad);
            this.Controls.Add(this.VolverAtrasBoton_EspacioAereo);
            this.Controls.Add(this.Conflicto);
            this.Controls.Add(this.MostarDatosButton);
            this.Controls.Add(this.Automáticobutton);
            this.Controls.Add(this.Moverbutton);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "EspacioAéreo";
            this.Text = "EspacioAéreo";
            this.Load += new System.EventHandler(this.EspacioAéreo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Button Moverbutton;
        private System.Windows.Forms.Timer timer1;
        private Button Automáticobutton;
        private Button MostarDatosButton;
        private Button Conflicto;
        private Button VolverAtrasBoton_EspacioAereo;
        private Button CambiarVelocidad;
        private Button Restart;
        private Button PuntoAnteriorButton;
        private Button guardarButton;
    }
}