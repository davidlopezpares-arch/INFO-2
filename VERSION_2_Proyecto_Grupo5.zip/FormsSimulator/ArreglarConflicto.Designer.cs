﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class ArreglarConflicto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Mensaje = new System.Windows.Forms.Label();
            this.SiButton = new System.Windows.Forms.Button();
            this.NoButton = new System.Windows.Forms.Button();
            this.RecomendacionVel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Mensaje
            // 
            this.Mensaje.AutoSize = true;
            this.Mensaje.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mensaje.Location = new System.Drawing.Point(240, 72);
            this.Mensaje.Name = "Mensaje";
            this.Mensaje.Size = new System.Drawing.Size(373, 24);
            this.Mensaje.TabIndex = 0;
            this.Mensaje.Text = "Los vuelos van a chocar. Quieres arreglarlo?";
            // 
            // SiButton
            // 
            this.SiButton.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SiButton.Location = new System.Drawing.Point(118, 134);
            this.SiButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SiButton.Name = "SiButton";
            this.SiButton.Size = new System.Drawing.Size(150, 50);
            this.SiButton.TabIndex = 1;
            this.SiButton.Text = "Si";
            this.SiButton.UseVisualStyleBackColor = true;
            this.SiButton.Click += new System.EventHandler(this.SiButton_Click);
            // 
            // NoButton
            // 
            this.NoButton.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NoButton.Location = new System.Drawing.Point(604, 134);
            this.NoButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NoButton.Name = "NoButton";
            this.NoButton.Size = new System.Drawing.Size(150, 50);
            this.NoButton.TabIndex = 2;
            this.NoButton.Text = "No";
            this.NoButton.UseVisualStyleBackColor = true;
            this.NoButton.Click += new System.EventHandler(this.NoButton_Click);
            // 
            // RecomendacionVel
            // 
            this.RecomendacionVel.AutoSize = true;
            this.RecomendacionVel.Location = new System.Drawing.Point(268, 227);
            this.RecomendacionVel.Name = "RecomendacionVel";
            this.RecomendacionVel.Size = new System.Drawing.Size(0, 20);
            this.RecomendacionVel.TabIndex = 3;
            // 
            // ArreglarConflicto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.RecomendacionVel);
            this.Controls.Add(this.NoButton);
            this.Controls.Add(this.SiButton);
            this.Controls.Add(this.Mensaje);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ArreglarConflicto";
            this.Text = "ArreglarConflicto";
            this.Load += new System.EventHandler(this.ArreglarConflicto_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Mensaje;
        private Button SiButton;
        private Button NoButton;
        private Label RecomendacionVel;
    }
}