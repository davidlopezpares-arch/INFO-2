﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class DistanciaVuelos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Distancia = new System.Windows.Forms.Label();
            this.VolverAtrasBoton_DistanciaVuelos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Distancia
            // 
            this.Distancia.Location = new System.Drawing.Point(321, 107);
            this.Distancia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Distancia.Name = "Distancia";
            this.Distancia.Size = new System.Drawing.Size(252, 212);
            this.Distancia.TabIndex = 0;
            this.Distancia.Text = "label1";
            this.Distancia.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // VolverAtrasBoton_DistanciaVuelos
            // 
            this.VolverAtrasBoton_DistanciaVuelos.Location = new System.Drawing.Point(365, 369);
            this.VolverAtrasBoton_DistanciaVuelos.Name = "VolverAtrasBoton_DistanciaVuelos";
            this.VolverAtrasBoton_DistanciaVuelos.Size = new System.Drawing.Size(150, 50);
            this.VolverAtrasBoton_DistanciaVuelos.TabIndex = 1;
            this.VolverAtrasBoton_DistanciaVuelos.Text = "Volver atrás";
            this.VolverAtrasBoton_DistanciaVuelos.UseVisualStyleBackColor = true;
            this.VolverAtrasBoton_DistanciaVuelos.Click += new System.EventHandler(this.VolverAtrasBoton_DistanciaVuelos_Click);
            // 
            // DistanciaVuelos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.VolverAtrasBoton_DistanciaVuelos);
            this.Controls.Add(this.Distancia);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "DistanciaVuelos";
            this.Text = "DistanciaVuelos";
            this.Load += new System.EventHandler(this.DistanciaVuelos_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Label Distancia;
        private Button VolverAtrasBoton_DistanciaVuelos;
    }
}