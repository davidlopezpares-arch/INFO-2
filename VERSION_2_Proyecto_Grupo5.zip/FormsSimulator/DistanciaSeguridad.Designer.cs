﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class DistanciaSeguridad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DistanciaS = new System.Windows.Forms.TextBox();
            this.TiempoC = new System.Windows.Forms.TextBox();
            this.AceptarButton = new System.Windows.Forms.Button();
            this.AutorellenarDistBoton = new System.Windows.Forms.Button();
            this.VolverAtrasButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(133, 112);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Distancia de seguridad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(356, 112);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tiempo de ciclo";
            // 
            // DistanciaS
            // 
            this.DistanciaS.Location = new System.Drawing.Point(141, 155);
            this.DistanciaS.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.DistanciaS.Name = "DistanciaS";
            this.DistanciaS.Size = new System.Drawing.Size(92, 20);
            this.DistanciaS.TabIndex = 2;
            // 
            // TiempoC
            // 
            this.TiempoC.Location = new System.Drawing.Point(356, 155);
            this.TiempoC.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.TiempoC.Name = "TiempoC";
            this.TiempoC.Size = new System.Drawing.Size(92, 20);
            this.TiempoC.TabIndex = 3;
            // 
            // AceptarButton
            // 
            this.AceptarButton.Location = new System.Drawing.Point(243, 265);
            this.AceptarButton.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.AceptarButton.Name = "AceptarButton";
            this.AceptarButton.Size = new System.Drawing.Size(100, 32);
            this.AceptarButton.TabIndex = 4;
            this.AceptarButton.Text = "Aceptar";
            this.AceptarButton.UseVisualStyleBackColor = true;
            this.AceptarButton.Click += new System.EventHandler(this.AceptarButton_Click);
            // 
            // AutorellenarDistBoton
            // 
            this.AutorellenarDistBoton.Location = new System.Drawing.Point(243, 218);
            this.AutorellenarDistBoton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AutorellenarDistBoton.Name = "AutorellenarDistBoton";
            this.AutorellenarDistBoton.Size = new System.Drawing.Size(100, 44);
            this.AutorellenarDistBoton.TabIndex = 5;
            this.AutorellenarDistBoton.Text = "Autorellenar Datos";
            this.AutorellenarDistBoton.UseVisualStyleBackColor = true;
            this.AutorellenarDistBoton.Click += new System.EventHandler(this.AutorellenarDistBoton_Click);
            // 
            // VolverAtrasButton
            // 
            this.VolverAtrasButton.Location = new System.Drawing.Point(474, 343);
            this.VolverAtrasButton.Margin = new System.Windows.Forms.Padding(2);
            this.VolverAtrasButton.Name = "VolverAtrasButton";
            this.VolverAtrasButton.Size = new System.Drawing.Size(100, 32);
            this.VolverAtrasButton.TabIndex = 6;
            this.VolverAtrasButton.Text = "Volver Atrás";
            this.VolverAtrasButton.UseVisualStyleBackColor = true;
            this.VolverAtrasButton.Click += new System.EventHandler(this.VolverAtrasButton_Click);
            // 
            // DistanciaSeguridad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 386);
            this.Controls.Add(this.VolverAtrasButton);
            this.Controls.Add(this.AutorellenarDistBoton);
            this.Controls.Add(this.AceptarButton);
            this.Controls.Add(this.TiempoC);
            this.Controls.Add(this.DistanciaS);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "DistanciaSeguridad";
            this.Text = "DistanciaSeguridad";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox DistanciaS;
        private TextBox TiempoC;
        private Button AceptarButton;
        private Button AutorellenarDistBoton;
        private Button VolverAtrasButton;
    }
}