﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class CrearCuenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CrearCuentaTitulo = new System.Windows.Forms.Label();
            this.AceptarButtonCrearCuenta = new System.Windows.Forms.Button();
            this.ContraseñaNuevaLabel = new System.Windows.Forms.Label();
            this.UsuarioNuevoLabel = new System.Windows.Forms.Label();
            this.ContraseñaNuevaTextBox = new System.Windows.Forms.TextBox();
            this.UsuarioNuevoTextBox = new System.Windows.Forms.TextBox();
            this.RepiteContraseñaLabel = new System.Windows.Forms.Label();
            this.RepiteContraseñaTextBox = new System.Windows.Forms.TextBox();
            this.VolverAtrasCrearCuenta = new System.Windows.Forms.Button();
            this.TextoCrearCuenta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CrearCuentaTitulo
            // 
            this.CrearCuentaTitulo.AutoSize = true;
            this.CrearCuentaTitulo.Font = new System.Drawing.Font("Bodoni MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CrearCuentaTitulo.Location = new System.Drawing.Point(316, 42);
            this.CrearCuentaTitulo.Name = "CrearCuentaTitulo";
            this.CrearCuentaTitulo.Size = new System.Drawing.Size(286, 34);
            this.CrearCuentaTitulo.TabIndex = 1;
            this.CrearCuentaTitulo.Text = "CREA UNA CUENTA";
            // 
            // AceptarButtonCrearCuenta
            // 
            this.AceptarButtonCrearCuenta.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.AceptarButtonCrearCuenta.Location = new System.Drawing.Point(403, 252);
            this.AceptarButtonCrearCuenta.Name = "AceptarButtonCrearCuenta";
            this.AceptarButtonCrearCuenta.Size = new System.Drawing.Size(150, 50);
            this.AceptarButtonCrearCuenta.TabIndex = 10;
            this.AceptarButtonCrearCuenta.Text = "Aceptar";
            this.AceptarButtonCrearCuenta.UseVisualStyleBackColor = true;
            this.AceptarButtonCrearCuenta.Click += new System.EventHandler(this.AceptarButtonCrearCuenta_Click);
            // 
            // ContraseñaNuevaLabel
            // 
            this.ContraseñaNuevaLabel.AutoSize = true;
            this.ContraseñaNuevaLabel.Location = new System.Drawing.Point(274, 163);
            this.ContraseñaNuevaLabel.Name = "ContraseñaNuevaLabel";
            this.ContraseñaNuevaLabel.Size = new System.Drawing.Size(96, 20);
            this.ContraseñaNuevaLabel.TabIndex = 9;
            this.ContraseñaNuevaLabel.Text = "Contraseña:";
            // 
            // UsuarioNuevoLabel
            // 
            this.UsuarioNuevoLabel.AutoSize = true;
            this.UsuarioNuevoLabel.Location = new System.Drawing.Point(302, 113);
            this.UsuarioNuevoLabel.Name = "UsuarioNuevoLabel";
            this.UsuarioNuevoLabel.Size = new System.Drawing.Size(68, 20);
            this.UsuarioNuevoLabel.TabIndex = 8;
            this.UsuarioNuevoLabel.Text = "Usuario:";
            // 
            // ContraseñaNuevaTextBox
            // 
            this.ContraseñaNuevaTextBox.Location = new System.Drawing.Point(378, 160);
            this.ContraseñaNuevaTextBox.Name = "ContraseñaNuevaTextBox";
            this.ContraseñaNuevaTextBox.Size = new System.Drawing.Size(199, 26);
            this.ContraseñaNuevaTextBox.TabIndex = 7;
            // 
            // UsuarioNuevoTextBox
            // 
            this.UsuarioNuevoTextBox.Location = new System.Drawing.Point(378, 110);
            this.UsuarioNuevoTextBox.Name = "UsuarioNuevoTextBox";
            this.UsuarioNuevoTextBox.Size = new System.Drawing.Size(199, 26);
            this.UsuarioNuevoTextBox.TabIndex = 6;
            // 
            // RepiteContraseñaLabel
            // 
            this.RepiteContraseñaLabel.AutoSize = true;
            this.RepiteContraseñaLabel.Location = new System.Drawing.Point(206, 208);
            this.RepiteContraseñaLabel.Name = "RepiteContraseñaLabel";
            this.RepiteContraseñaLabel.Size = new System.Drawing.Size(160, 20);
            this.RepiteContraseñaLabel.TabIndex = 12;
            this.RepiteContraseñaLabel.Text = "Repite la contraseña:";
            // 
            // RepiteContraseñaTextBox
            // 
            this.RepiteContraseñaTextBox.Location = new System.Drawing.Point(378, 205);
            this.RepiteContraseñaTextBox.Name = "RepiteContraseñaTextBox";
            this.RepiteContraseñaTextBox.Size = new System.Drawing.Size(199, 26);
            this.RepiteContraseñaTextBox.TabIndex = 11;
            // 
            // VolverAtrasCrearCuenta
            // 
            this.VolverAtrasCrearCuenta.Location = new System.Drawing.Point(403, 362);
            this.VolverAtrasCrearCuenta.Name = "VolverAtrasCrearCuenta";
            this.VolverAtrasCrearCuenta.Size = new System.Drawing.Size(150, 50);
            this.VolverAtrasCrearCuenta.TabIndex = 13;
            this.VolverAtrasCrearCuenta.Text = "Volver atrás";
            this.VolverAtrasCrearCuenta.UseVisualStyleBackColor = true;
            this.VolverAtrasCrearCuenta.Click += new System.EventHandler(this.VolverAtrasCrearCuenta_Click);
            // 
            // TextoCrearCuenta
            // 
            this.TextoCrearCuenta.AutoSize = true;
            this.TextoCrearCuenta.Location = new System.Drawing.Point(399, 328);
            this.TextoCrearCuenta.Name = "TextoCrearCuenta";
            this.TextoCrearCuenta.Size = new System.Drawing.Size(141, 20);
            this.TextoCrearCuenta.TabIndex = 14;
            this.TextoCrearCuenta.Text = "Ya tienes Cuenta?";
            // 
            // CrearCuenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.TextoCrearCuenta);
            this.Controls.Add(this.VolverAtrasCrearCuenta);
            this.Controls.Add(this.RepiteContraseñaLabel);
            this.Controls.Add(this.RepiteContraseñaTextBox);
            this.Controls.Add(this.AceptarButtonCrearCuenta);
            this.Controls.Add(this.ContraseñaNuevaLabel);
            this.Controls.Add(this.UsuarioNuevoLabel);
            this.Controls.Add(this.ContraseñaNuevaTextBox);
            this.Controls.Add(this.UsuarioNuevoTextBox);
            this.Controls.Add(this.CrearCuentaTitulo);
            this.Name = "CrearCuenta";
            this.Text = "CrearCuenta";
            this.Load += new System.EventHandler(this.CrearCuenta_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label CrearCuentaTitulo;
        private Button AceptarButtonCrearCuenta;
        private Label ContraseñaNuevaLabel;
        private Label UsuarioNuevoLabel;
        private TextBox ContraseñaNuevaTextBox;
        private TextBox UsuarioNuevoTextBox;
        private Label RepiteContraseñaLabel;
        private TextBox RepiteContraseñaTextBox;
        private Button VolverAtrasCrearCuenta;
        private Label TextoCrearCuenta;
    }
}