﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class InfoVuelo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Matriz = new System.Windows.Forms.DataGridView();
            this.VolverAtrasBoton_InfoVuelo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Matriz)).BeginInit();
            this.SuspendLayout();
            // 
            // Matriz
            // 
            this.Matriz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Matriz.Location = new System.Drawing.Point(22, 10);
            this.Matriz.Margin = new System.Windows.Forms.Padding(2);
            this.Matriz.Name = "Matriz";
            this.Matriz.RowHeadersWidth = 62;
            this.Matriz.Size = new System.Drawing.Size(845, 522);
            this.Matriz.TabIndex = 0;
            // 
            // VolverAtrasBoton_InfoVuelo
            // 
            this.VolverAtrasBoton_InfoVuelo.Location = new System.Drawing.Point(328, 553);
            this.VolverAtrasBoton_InfoVuelo.Name = "VolverAtrasBoton_InfoVuelo";
            this.VolverAtrasBoton_InfoVuelo.Size = new System.Drawing.Size(172, 29);
            this.VolverAtrasBoton_InfoVuelo.TabIndex = 1;
            this.VolverAtrasBoton_InfoVuelo.Text = "Volver atrás";
            this.VolverAtrasBoton_InfoVuelo.UseVisualStyleBackColor = true;
            this.VolverAtrasBoton_InfoVuelo.Click += new System.EventHandler(this.VolverAtrasBoton_InfoVuelo_Click);
            // 
            // InfoVuelo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.VolverAtrasBoton_InfoVuelo);
            this.Controls.Add(this.Matriz);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "InfoVuelo";
            this.Text = "InfoVuelo";
            this.Load += new System.EventHandler(this.InfoVuelo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Matriz)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridView Matriz;
        private Button VolverAtrasBoton_InfoVuelo;
    }
}