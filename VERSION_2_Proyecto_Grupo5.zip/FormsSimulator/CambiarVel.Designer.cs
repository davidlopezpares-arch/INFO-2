﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class CambiarVel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Vuelolbl = new System.Windows.Forms.Label();
            this.AceptarBtn = new System.Windows.Forms.Button();
            this.VelocidadBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.volveratrasButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Vuelolbl
            // 
            this.Vuelolbl.AutoSize = true;
            this.Vuelolbl.Location = new System.Drawing.Point(105, 159);
            this.Vuelolbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Vuelolbl.Name = "Vuelolbl";
            this.Vuelolbl.Size = new System.Drawing.Size(51, 20);
            this.Vuelolbl.TabIndex = 0;
            this.Vuelolbl.Text = "label1";
            // 
            // AceptarBtn
            // 
            this.AceptarBtn.Location = new System.Drawing.Point(518, 159);
            this.AceptarBtn.Margin = new System.Windows.Forms.Padding(2);
            this.AceptarBtn.Name = "AceptarBtn";
            this.AceptarBtn.Size = new System.Drawing.Size(150, 50);
            this.AceptarBtn.TabIndex = 1;
            this.AceptarBtn.Text = "Aceptar";
            this.AceptarBtn.UseVisualStyleBackColor = true;
            this.AceptarBtn.Click += new System.EventHandler(this.AceptarBtn_Click);
            // 
            // VelocidadBox
            // 
            this.VelocidadBox.Location = new System.Drawing.Point(303, 162);
            this.VelocidadBox.Margin = new System.Windows.Forms.Padding(2);
            this.VelocidadBox.Name = "VelocidadBox";
            this.VelocidadBox.Size = new System.Drawing.Size(136, 26);
            this.VelocidadBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(303, 127);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nueva Velocidad";
            // 
            // volveratrasButton
            // 
            this.volveratrasButton.Location = new System.Drawing.Point(347, 445);
            this.volveratrasButton.Name = "volveratrasButton";
            this.volveratrasButton.Size = new System.Drawing.Size(150, 50);
            this.volveratrasButton.TabIndex = 4;
            this.volveratrasButton.Text = "Volver Atrás";
            this.volveratrasButton.UseVisualStyleBackColor = true;
            this.volveratrasButton.Click += new System.EventHandler(this.volveratrasButton_Click);
            // 
            // CambiarVel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.volveratrasButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.VelocidadBox);
            this.Controls.Add(this.AceptarBtn);
            this.Controls.Add(this.Vuelolbl);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CambiarVel";
            this.Text = "CambiarVel";
            this.Load += new System.EventHandler(this.CambiarVel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Vuelolbl;
        private Button AceptarBtn;
        private TextBox VelocidadBox;
        private Label label2;
        private Button volveratrasButton;
    }
}