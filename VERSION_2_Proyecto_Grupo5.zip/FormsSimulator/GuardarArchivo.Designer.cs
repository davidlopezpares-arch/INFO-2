﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class GuardarArchivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aceptarButton = new System.Windows.Forms.Button();
            this.volveratrasButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // aceptarButton
            // 
            this.aceptarButton.Location = new System.Drawing.Point(343, 298);
            this.aceptarButton.Name = "aceptarButton";
            this.aceptarButton.Size = new System.Drawing.Size(150, 50);
            this.aceptarButton.TabIndex = 0;
            this.aceptarButton.Text = "Aceptar y guardar";
            this.aceptarButton.UseVisualStyleBackColor = true;
            this.aceptarButton.Click += new System.EventHandler(this.aceptarButton_Click);
            // 
            // volveratrasButton
            // 
            this.volveratrasButton.Location = new System.Drawing.Point(340, 525);
            this.volveratrasButton.Name = "volveratrasButton";
            this.volveratrasButton.Size = new System.Drawing.Size(143, 29);
            this.volveratrasButton.TabIndex = 1;
            this.volveratrasButton.Text = "Volver Atrás";
            this.volveratrasButton.UseVisualStyleBackColor = true;
            this.volveratrasButton.Click += new System.EventHandler(this.volveratrasButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(280, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Escribe el nombre para el archivo:";
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.Location = new System.Drawing.Point(343, 237);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(140, 26);
            this.nombreTextBox.TabIndex = 3;
            // 
            // GuardarArchivo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.volveratrasButton);
            this.Controls.Add(this.aceptarButton);
            this.Name = "GuardarArchivo";
            this.Text = "GuardarArchivo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button aceptarButton;
        private Button volveratrasButton;
        private Label label1;
        private TextBox nombreTextBox;
    }
}