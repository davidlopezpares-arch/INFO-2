﻿using System; using System.Drawing; using System.Windows.Forms; namespace FormsSimulator
{
    partial class NuevoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Id1 = new System.Windows.Forms.TextBox();
            this.PosicionInicial1 = new System.Windows.Forms.TextBox();
            this.PosicionFinal1 = new System.Windows.Forms.TextBox();
            this.Velocidad1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Velocidad2 = new System.Windows.Forms.TextBox();
            this.PosicionFinal2 = new System.Windows.Forms.TextBox();
            this.PosicionInicial2 = new System.Windows.Forms.TextBox();
            this.Id2 = new System.Windows.Forms.TextBox();
            this.Aceptarbutton = new System.Windows.Forms.Button();
            this.AutorellenarBoton = new System.Windows.Forms.Button();
            this.VolverAtrasNuevoForm = new System.Windows.Forms.Button();
            this.CompaniaLabel1 = new System.Windows.Forms.Label();
            this.Compania1 = new System.Windows.Forms.TextBox();
            this.CompaniaLabel2 = new System.Windows.Forms.Label();
            this.Compania2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Id1
            // 
            this.Id1.Location = new System.Drawing.Point(255, 150);
            this.Id1.Margin = new System.Windows.Forms.Padding(2);
            this.Id1.Name = "Id1";
            this.Id1.Size = new System.Drawing.Size(136, 26);
            this.Id1.TabIndex = 0;
            // 
            // PosicionInicial1
            // 
            this.PosicionInicial1.Location = new System.Drawing.Point(255, 210);
            this.PosicionInicial1.Margin = new System.Windows.Forms.Padding(2);
            this.PosicionInicial1.Name = "PosicionInicial1";
            this.PosicionInicial1.Size = new System.Drawing.Size(136, 26);
            this.PosicionInicial1.TabIndex = 1;
            // 
            // PosicionFinal1
            // 
            this.PosicionFinal1.Location = new System.Drawing.Point(255, 273);
            this.PosicionFinal1.Margin = new System.Windows.Forms.Padding(2);
            this.PosicionFinal1.Name = "PosicionFinal1";
            this.PosicionFinal1.Size = new System.Drawing.Size(136, 26);
            this.PosicionFinal1.TabIndex = 2;
            // 
            // Velocidad1
            // 
            this.Velocidad1.Location = new System.Drawing.Point(255, 328);
            this.Velocidad1.Margin = new System.Windows.Forms.Padding(2);
            this.Velocidad1.Name = "Velocidad1";
            this.Velocidad1.Size = new System.Drawing.Size(136, 26);
            this.Velocidad1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 123);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Vuelo 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(149, 153);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Identificador";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(105, 213);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Posición Inicial (x,y)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(111, 275);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Posición Final (x,y)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 331);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Velocidad";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(479, 328);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Velocidad";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(421, 272);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "Posición Final (x,y)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(415, 213);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "Posición Inicial (x,y)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(459, 150);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Identificador";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(564, 121);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 20);
            this.label10.TabIndex = 13;
            this.label10.Text = "Vuelo 2";
            // 
            // Velocidad2
            // 
            this.Velocidad2.Location = new System.Drawing.Point(564, 326);
            this.Velocidad2.Margin = new System.Windows.Forms.Padding(2);
            this.Velocidad2.Name = "Velocidad2";
            this.Velocidad2.Size = new System.Drawing.Size(136, 26);
            this.Velocidad2.TabIndex = 12;
            // 
            // PosicionFinal2
            // 
            this.PosicionFinal2.Location = new System.Drawing.Point(564, 270);
            this.PosicionFinal2.Margin = new System.Windows.Forms.Padding(2);
            this.PosicionFinal2.Name = "PosicionFinal2";
            this.PosicionFinal2.Size = new System.Drawing.Size(136, 26);
            this.PosicionFinal2.TabIndex = 11;
            // 
            // PosicionInicial2
            // 
            this.PosicionInicial2.Location = new System.Drawing.Point(564, 207);
            this.PosicionInicial2.Margin = new System.Windows.Forms.Padding(2);
            this.PosicionInicial2.Name = "PosicionInicial2";
            this.PosicionInicial2.Size = new System.Drawing.Size(136, 26);
            this.PosicionInicial2.TabIndex = 10;
            // 
            // Id2
            // 
            this.Id2.Location = new System.Drawing.Point(564, 148);
            this.Id2.Margin = new System.Windows.Forms.Padding(2);
            this.Id2.Name = "Id2";
            this.Id2.Size = new System.Drawing.Size(136, 26);
            this.Id2.TabIndex = 9;
            // 
            // Aceptarbutton
            // 
            this.Aceptarbutton.Location = new System.Drawing.Point(357, 413);
            this.Aceptarbutton.Margin = new System.Windows.Forms.Padding(2);
            this.Aceptarbutton.Name = "Aceptarbutton";
            this.Aceptarbutton.Size = new System.Drawing.Size(150, 50);
            this.Aceptarbutton.TabIndex = 18;
            this.Aceptarbutton.Text = "Aceptar y guardar";
            this.Aceptarbutton.UseVisualStyleBackColor = true;
            this.Aceptarbutton.Click += new System.EventHandler(this.Aceptarbutton_Click);
            // 
            // AutorellenarBoton
            // 
            this.AutorellenarBoton.Location = new System.Drawing.Point(186, 413);
            this.AutorellenarBoton.Name = "AutorellenarBoton";
            this.AutorellenarBoton.Size = new System.Drawing.Size(150, 50);
            this.AutorellenarBoton.TabIndex = 19;
            this.AutorellenarBoton.Text = "Autorellenar Datos";
            this.AutorellenarBoton.UseVisualStyleBackColor = true;
            this.AutorellenarBoton.Click += new System.EventHandler(this.AutorellenarBoton_Click);
            // 
            // VolverAtrasNuevoForm
            // 
            this.VolverAtrasNuevoForm.Location = new System.Drawing.Point(528, 413);
            this.VolverAtrasNuevoForm.Margin = new System.Windows.Forms.Padding(2);
            this.VolverAtrasNuevoForm.Name = "VolverAtrasNuevoForm";
            this.VolverAtrasNuevoForm.Size = new System.Drawing.Size(150, 50);
            this.VolverAtrasNuevoForm.TabIndex = 20;
            this.VolverAtrasNuevoForm.Text = "Volver atrás";
            this.VolverAtrasNuevoForm.UseVisualStyleBackColor = true;
            this.VolverAtrasNuevoForm.Click += new System.EventHandler(this.VolverAtrasNuevoForm_Click);
            // 
            // CompaniaLabel1
            // 
            this.CompaniaLabel1.AutoSize = true;
            this.CompaniaLabel1.Location = new System.Drawing.Point(153, 378);
            this.CompaniaLabel1.Name = "CompaniaLabel1";
            this.CompaniaLabel1.Size = new System.Drawing.Size(90, 20);
            this.CompaniaLabel1.TabIndex = 21;
            this.CompaniaLabel1.Text = "Compañia1";
            // 
            // Compania1
            // 
            this.Compania1.Location = new System.Drawing.Point(255, 375);
            this.Compania1.Name = "Compania1";
            this.Compania1.Size = new System.Drawing.Size(140, 26);
            this.Compania1.TabIndex = 22;
            // 
            // CompaniaLabel2
            // 
            this.CompaniaLabel2.AutoSize = true;
            this.CompaniaLabel2.Location = new System.Drawing.Point(462, 382);
            this.CompaniaLabel2.Name = "CompaniaLabel2";
            this.CompaniaLabel2.Size = new System.Drawing.Size(90, 20);
            this.CompaniaLabel2.TabIndex = 23;
            this.CompaniaLabel2.Text = "Compañia2";
            // 
            // Compania2
            // 
            this.Compania2.Location = new System.Drawing.Point(564, 375);
            this.Compania2.Name = "Compania2";
            this.Compania2.Size = new System.Drawing.Size(140, 26);
            this.Compania2.TabIndex = 24;
            // 
            // NuevoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 594);
            this.Controls.Add(this.Compania2);
            this.Controls.Add(this.CompaniaLabel2);
            this.Controls.Add(this.Compania1);
            this.Controls.Add(this.CompaniaLabel1);
            this.Controls.Add(this.VolverAtrasNuevoForm);
            this.Controls.Add(this.AutorellenarBoton);
            this.Controls.Add(this.Aceptarbutton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Velocidad2);
            this.Controls.Add(this.PosicionFinal2);
            this.Controls.Add(this.PosicionInicial2);
            this.Controls.Add(this.Id2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Velocidad1);
            this.Controls.Add(this.PosicionFinal1);
            this.Controls.Add(this.PosicionInicial1);
            this.Controls.Add(this.Id1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "NuevoForm";
            this.Text = "NuevoForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Id1;
        private TextBox PosicionInicial1;
        private TextBox PosicionFinal1;
        private TextBox Velocidad1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private TextBox Velocidad2;
        private TextBox PosicionFinal2;
        private TextBox PosicionInicial2;
        private TextBox Id2;
        private Button Aceptarbutton;
        private Button AutorellenarBoton;
        private Button VolverAtrasNuevoForm;
        private Label CompaniaLabel1;
        private TextBox Compania1;
        private Label CompaniaLabel2;
        private TextBox Compania2;
    }
}