﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class FlightPlanList
    {
        //ATTRIBUTES
        List<FlightPlan> vector = new List<FlightPlan>();

        //CONSTRUCTOR

        //METHODS
        public int AddFlightPlan(FlightPlan p)
        {
            vector.Add(p);
            return 0;
        }
        public FlightPlan GetFlightPlan(int i)
        {
            if (i < 0 || i >= vector.Count)
            {
                return null;
            }
            else
            {
                return vector[i]; 
            }
        }
        public int GetNumFlightPlans()
        {
            return vector.Count;
        }
        public void Mover(double tiempo)
        {
            int i = 0;
            while (i < vector.Count)
            {
                vector[i].Mover(tiempo);
                i++;
            }
        }
        public void EscribeConsola()
        {
            int i = 0;
            while (i < vector.Count)
            {
                vector[i].EscribeConsola();
                i++;
            }
        }

        public FlightPlanList Copia()
        {
            FlightPlanList copia = new FlightPlanList();
            int i = 0;

            while (i < vector.Count)
            {
                copia.AddFlightPlan(vector[i].Copia());
                i++;
            }

            return copia;
        }
    }
}
