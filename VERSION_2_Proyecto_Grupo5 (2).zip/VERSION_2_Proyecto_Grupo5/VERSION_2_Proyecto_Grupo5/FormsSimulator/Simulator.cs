using FlightLib;

namespace FormsSimulator
{
    public partial class Simulator : Form
    {
        public Simulator()
        {
            InitializeComponent();
        }
        FlightPlanList milista = new FlightPlanList();
        double distancia;
        int tiempo;
        bool enviado; // Variable que se utiliza para indicar si se ha enviado la información de distancia y tiempo desde el formulario DistanciaSeguridad

        private void nuevoFormularioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NuevoForm Form = new NuevoForm();
            Form.ShowDialog();
            milista = Form.GetLista();
        }

        private void distSeguridadYTCicloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DistanciaSeguridad Form = new DistanciaSeguridad();
            Form.ShowDialog();
            distancia = Form.GetDistancia();
            tiempo = Form.GetCiclo();
            enviado = Form.GetEnviado();
        }

        private void espacioAéreoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (milista == null || !enviado)
            {
                MessageBox.Show("No se han cargado los planes de vuelo y/o los parámetros de distancia y/o tiempo deben estar definidos.");
                return;
            }

            bool encontrado = false;
            bool conflicto = false;
            bool abierto = false;

            while (!encontrado && !conflicto)
            {
                milista.Mover(tiempo);
                int i = 0;
                while (i < milista.GetNumFlightPlans() && !conflicto)
                {
                    int j = i + 1;
                    while (j < milista.GetNumFlightPlans() && !conflicto)
                    {
                        if (milista.GetFlightPlan(i).Conflicto(milista.GetFlightPlan(j), 2 * distancia))
                        {
                            conflicto = true;
                        }
                        else
                        {
                            j = j + 1;
                        }
                    }

                    if (!conflicto)
                    {
                        i = i + 1;
                    }
                }
                int k = 0;
                while (k < milista.GetNumFlightPlans() && !encontrado)
                {
                    if (milista.GetFlightPlan(k).EstaDestino())
                    {
                        encontrado = true;
                    }
                    k = k + 1;
                }
            }

            int n = 0;
            while (n < milista.GetNumFlightPlans())
            {
                milista.GetFlightPlan(n).Restart();
                n = n + 1;
            }

            if (conflicto)
            {
                ArreglarConflicto form = new ArreglarConflicto();
                form.SetFlightPlanList(milista);
                form.SetDistancia(distancia);
                form.SetTiempo(tiempo);
                form.ShowDialog();
                milista = form.GetLista();
            }
            else
            {
                EspacioAéreo Form = new EspacioAéreo();
                Form.SetLista(milista);
                Form.SetDistancia(distancia);
                Form.SetTiempo(tiempo);
                Form.ShowDialog();
                milista = Form.GetLista();
            }
        }
        

        private void cargarVuelosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CargarArchivo Form = new CargarArchivo();
            Form.ShowDialog();
            milista = Form.GetLista();
        }
    }
}
