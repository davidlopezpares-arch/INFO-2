﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class FlightPlanList
    {
        //ATTRIBUTES
        FlightPlan[] vector = new FlightPlan[10];
        int number = 0;

        //CONSTRUCTOR

        //METHODS
        public int AddFlightPlan(FlightPlan p)
        {
            if (number < 10)
            {
                vector[number] = p;
                number++;
                return 0; 
            }
            else
            {
                return -1; 
            }
        }
        public FlightPlan GetFlightPlan(int i)
        {
            if (i < 0 && i > number)
            {
                return null;
            }
            else
            {
                return vector[i]; 
            }
        }
        public int GetNumFlightPlans()
        {
            return number;
        }
        public void Mover(double tiempo)
        {
            int i = 0;
            while (i < number)
            {
                vector[i].Mover(tiempo);
                i++;
            }
        }
        public void EscribeConsola()
        {
            int i = 0;
            while (i < number)
            {
                vector[i].EscribeConsola();
                i++;
            }
        }
    }
}
